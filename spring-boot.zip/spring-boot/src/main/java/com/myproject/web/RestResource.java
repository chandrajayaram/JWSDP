package com.myproject.web;

import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/hello")
public class RestResource {
		
		@RequestMapping(method = RequestMethod.GET)
		//@PreAuthorize("hasAnyRole('ROLE_USER','USER','ROLE_ADMIN','ADMIN')")
	    String home() {
			UserDetails userDetails =
					 (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
			
			System.out.println(userDetails.getAuthorities());
			return "Hello World!";
	    }
}
