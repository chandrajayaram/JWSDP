/**
 * $Header: //depot/Perforce Depot/Market Systems/Applications/Integration-WS/Framework/src/java/com/caiso/soa/framework/common/util/XMLBindUtility.java#4 $
 * $Revision: #4 $
 * $Date: 2013/01/04 $
 * $Author: iloh $
 */
package com.caiso.soa.framework.common.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.io.StringWriter;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.MarshalException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.PropertyException;
import javax.xml.bind.Unmarshaller;
import javax.xml.bind.ValidationEvent;
import javax.xml.bind.ValidationEventHandler;
import javax.xml.transform.stream.StreamResult;

import org.apache.log4j.Logger;

import com.caiso.soa.framework.common.OutputDataTypeConstants;
import com.caiso.soa.framework.common.exception.XMLBindException;
import com.sun.xml.bind.marshaller.NamespacePrefixMapper;


/*
 * A Convenience utility for marshalling and unmarshalling XML using JAXB
 * 
 * @author <a href="mailto:mpope@caiso.com?Subject=JAVADOC - Question about
 * com.caiso.soa.ehs.common.util.XMLBindUtility.java"> Mark Pope </a>
 * 
 * @version $Revision: #4 $ $Date: 2013/01/04 $
 * 
 * @Copyright (c) California ISO 2005
 *  
 */
public class XMLBindUtility {

	private Unmarshaller unmarshaller = null;

	private Marshaller marshaller = null;

	private JAXBContext jc = null;

	private String mutex = new String("LockObject");
	private Logger logger = Logger.getLogger(getClass().getName());
	private ServiceHelper m_serviceHelper = null;
	private String[] m_ignoreValidationMessages = {};
	public static final String[] IGNORE_VALIDATION_MESSAGES_DFLT = { "Unexpected element", "is not allowed" };

	/**
	 * Constructor that requires package name of JAXB genned classes. Typically
	 * this is the package where jaxb.properties resides.
	 * 
	 * @throws XMLBindException
	 */
	public XMLBindUtility(String pContext) throws XMLBindException {
		// create a JAXBContext capable of handling classes generated into
		// the ...data.dto package
		try {
			jc = JAXBContext.newInstance(pContext, Thread.currentThread().getContextClassLoader());
		} catch (Exception e) {
			throw new XMLBindException("[XMLBindUtility] Context: \'" + pContext + "\' is not a valid JAXB package", e);
		}
	}

	/**
	 * Constructor that uses the passed ServiceHelper to create the JAXBContext
	 * 
	 * @param svcHelper
	 * @throws XMLBindException
	 */
	public XMLBindUtility(ServiceHelper svcHelper) throws XMLBindException {
		this(svcHelper.getJAXBContextPath());
		setServiceHelper(svcHelper);
	}

	public void setServiceHelper(ServiceHelper svcHelper) {
		m_serviceHelper = svcHelper;
	}

	public ServiceHelper getServiceHelper() {
		return m_serviceHelper;
	}

	/**
	 * String patterns of errors to ignore during unmarshalling. Returns
	 * {@link #IGNORE_VALIDATION_MESSAGES_DFLT} if values are not provided.
	 * 
	 * @return
	 */
	public String[] getIgnoreValidationMessages() {
		if (m_ignoreValidationMessages == null || m_ignoreValidationMessages.length == 0) {
			return IGNORE_VALIDATION_MESSAGES_DFLT;
		} else {
			return m_ignoreValidationMessages;
		}
	}

	/**
	 * String patterns of errors to ignore during unmarshalling
	 * 
	 * @param ignoreValidationMessages
	 */
	public void setIgnoreValidationMessages(String[] ignoreValidationMessages) {
		m_ignoreValidationMessages = ignoreValidationMessages;
	}

	/**
	 * Create Java Objects from an XML String
	 * 
	 * @param pEventData
	 *            XML String
	 * @return JAXB Object Model
	 * @throws JAXBException
	 */
	public Object unmarshal(String pEventData) throws XMLBindException {
		return unmarshal(new ByteArrayInputStream(pEventData.getBytes()));
	}

	/**
	 * Create Java Objects from an input stream
	 * 
	 * @param pStream
	 *            InputStream
	 * @throws JAXBException
	 * @return JAXB Object Model
	 * @throws JAXBException
	 * @throws XMLBindException
	 */
	public Object unmarshal(InputStream pStream) throws XMLBindException {

		Object data = null;
		try {
			synchronized (mutex) {
				if (unmarshaller == null) {
					unmarshaller = jc.createUnmarshaller();
					unmarshaller.setValidating(true);
					if (getServiceHelper() != null && !getServiceHelper().isValidateRequest()) {
						// use lenient ValidationEventHandler
						unmarshaller.setEventHandler(getValidationEventHandler());
					}
				}

				data = unmarshaller.unmarshal(pStream);
			}
			return data;
		} catch (JAXBException e) {
			throw new XMLBindException(e);
		}
	}

	/**
	 * Create Java Objects from File
	 * 
	 * @param pFile
	 *            File that contains XML data
	 * @return JAXB object model
	 * @throws JAXBException
	 * @throws JAXBException
	 * @throws JAXBException
	 * @throws FileNotFoundException
	 */
	public Object unmarshal(File pFile) throws FileNotFoundException, XMLBindException {
		return unmarshal(new FileInputStream(pFile));
	}

	/**
	 * Extracts data as XML from Java Objects.
	 * 
	 * @param pPojo
	 * @return
	 * @throws JAXBException
	 * @throws XMLBindException
	 */
	public String marshal(Object pPojo) throws XMLBindException {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		StreamResult result = new StreamResult(baos);
		try {
			synchronized (mutex) {
				getMarshaller().marshal(pPojo, result);
			}
		} catch (MarshalException e) {
			// Attempting to marshal an unsupported type. Return back a
			// framework error
			// OutputDataType
			try {
				String errMsg = "";
				String stackTrace = "";
				if (pPojo instanceof Exception) {
					errMsg = ((Exception) pPojo).getMessage();
					StringWriter writer = new StringWriter();
					((Exception) pPojo).printStackTrace(new PrintWriter(writer));
					stackTrace = writer.toString();
				} else {
					errMsg = pPojo.toString();
				}
				try {
					String outputDataType = SOAPUtility.createOutputDataType("FMK007", "Framework",
							OutputDataTypeConstants.SEVERITY_ERROR, "Object type " + pPojo.getClass().getName()
									+ " cannot be marshaled.  Review client code.  " + "Original error: " + errMsg,
							"Framework", "Framework", "Framework", "");
					Logger.getLogger(getClass())
							.error("Object type " + pPojo.getClass().getName()
									+ " cannot be marshaled.  Review client code.  " + "Original error: " + errMsg
									+ ", stack trace: " + stackTrace);
					return outputDataType;
				} catch (Exception e1) {
					throw new XMLBindException(e);
				}
			} catch (Exception e1) {
				throw new XMLBindException(e1);
			}
		} catch (JAXBException e) {
			throw new XMLBindException(e);
		}

		return baos.toString();
	}

	/**
	 * Create an outputDataType object
	 * 
	 * @param eventResult
	 *            The result of the event.
	 * @param eventName
	 *            The name for this event.
	 * @param eventSeverity
	 *            The severity for the Event.
	 * @param eventType
	 *            The type of the event.
	 * @param eventDescription
	 *            Any description associated with the event.
	 * @param serviceName
	 *            The serviceName that spawned the event.
	 * @param serviceDescription
	 *            The service Description
	 * @param serviceComments
	 *            Any service related comments
	 * @return An XML String representing an OutputDataType.
	 * 
	 * @throws JAXBException
	 * @throws XMLBindException
	 */
	
	/**
	 * @see marshal(Object) adds mapping for namespaces
	 * 
	 * @param pOutputDataType
	 * @param pMapper
	 * @return
	 * @throws JAXBException
	 */
	public String marshal(Object pOutputDataType, NamespacePrefixMapper pMapper) throws XMLBindException {
		try {
			getMarshaller().setProperty("com.sun.xml.bind.namespacePrefixMapper", pMapper);
		} catch (PropertyException e) {
			throw new XMLBindException(e);
		}
		return marshal(pOutputDataType);

	}

	/**
	 * Tabbed formmated XML string for printing purposes
	 * 
	 * @throws JAXBException
	 */
	public void prettyPrint() throws XMLBindException {
		try {
			getMarshaller().setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
		} catch (PropertyException e) {
			throw new XMLBindException(e);
		}
	}

	/**
	 * Ensure the marshaller is always available.
	 * 
	 * @return Marshaller
	 * @throws JAXBException
	 */
	private Marshaller getMarshaller() throws XMLBindException {
		if (marshaller == null) {
			try {
				marshaller = jc.createMarshaller();
			} catch (JAXBException e) {
				throw new XMLBindException(e);
			}
		}
		return marshaller;
	}

	/**
	 * Returns a 'lenient' implementation of ValidationEventHandler that allows
	 * any validation errors that match the String patterns defined in
	 * {@link #getIgnoreValidationMessages()}. These error events are written to
	 * log instead of triggering an Exception.
	 * 
	 * @return
	 */
	protected ValidationEventHandler getValidationEventHandler() {
		return new ValidationEventHandler() {
			public boolean handleEvent(ValidationEvent event) {
				for (String s : getIgnoreValidationMessages()) {
					if (event.getMessage().indexOf(s) != -1) {
						logger.info("Skipping element: " + getValidationEventAsString(event));
						return true;
					}
				}
				logger.error(getValidationEventAsString(event));
				return false;
			}

			/**
			 * Convenience method to format the contents of a ValidationEvent to
			 * readable format.
			 * 
			 * @return
			 */
			protected String getValidationEventAsString(ValidationEvent event) {
				StringBuffer sb = new StringBuffer();
				sb.append("severity=");
				switch (event.getSeverity()) {
				case ValidationEvent.ERROR:
					sb.append("ERROR");
					break;
				case ValidationEvent.FATAL_ERROR:
					sb.append("FATAL ERROR");
					break;
				case ValidationEvent.WARNING:
					sb.append("WARNING");
					break;
				default:
					sb.append("Unknown event severity " + event.getSeverity());
				}
				sb.append(";message=" + event.getMessage());

				sb.append(";locator=["); // + event.getLocator().toString());
				sb.append("node=" + event.getLocator().getNode());
				sb.append(",object=" + event.getLocator().getObject());
				sb.append(",url=" + event.getLocator().getURL());
				sb.append(",line=" + event.getLocator().getLineNumber());
				sb.append(",col=" + event.getLocator().getColumnNumber());
				sb.append(",offset=" + event.getLocator().getOffset());
				sb.append("]");
				return sb.toString();
			}
		};
	}
	
}
