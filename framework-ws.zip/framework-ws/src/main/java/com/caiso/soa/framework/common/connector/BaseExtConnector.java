/*
 * Copyright (c) 2006 California ISO. All rights reserved.
 */
package com.caiso.soa.framework.common.connector;

import java.util.Map;

import com.caiso.soa.framework.common.exception.ConnectorException;
import com.caiso.soa.framework.common.exception.OutputDataTypeException;
import com.caiso.soa.framework.common.exception.XMLBindException;
import com.caiso.soa.framework.common.interfaces.IExtConnectorAdapter;
import com.caiso.soa.framework.common.util.ServiceHelper;
import com.caiso.soa.framework.common.util.XMLBindUtility;


/**
 * Base class for connector.
 *
 * @author <a href="mailto:mpope@caiso.com?Subject=JAVADOC - Question about ${package_name}.${file_name}">
 *         Mark Pope</a>
 * @version $$Revision:  $$ $$Date:  $$
*  @Copyright (c) California ISO 2006
 */
public class BaseExtConnector implements IExtConnectorAdapter {
    private String dataType = null;
    private String service = null;
    private XMLBindUtility bindUtility = null;

    /**
     * Get the bind utility for the passed in service. If the service changed from the
     * last call to the getBindUtility method then create a new bind utility.
     *
     * @param pService - the service to create the bindUtility for.
     *
     * @return the bind utility.
     *
     * @throws XMLBindException
     */
    public XMLBindUtility getBindUtility(String pService)
        throws XMLBindException {
        if (!pService.equals(service)) {
            bindUtility = null;
            service = pService;
        }

        if (bindUtility == null) {
            bindUtility =
                new XMLBindUtility(new ServiceHelper(service).getJAXBContextPath());
        }

        return bindUtility;
    }

    /**
     * Data Type defines the onMessage method to call. Valid values for data type are XML
     * or OJBECT - if the data type is defines as XML then the String onMessage(...)
     * method will be called, if the data type is defines as OBJECT then the Object
     * onMessage(...) method will be called. This value is set for each connector in the
     * property file on the property
     *
     * @see com.caiso.soa.framework.ejb.connector.IConnectorAdapter#setDataType(java.lang.String)
     */
    public void setDataType(String pDataType) {
        dataType = pDataType;
    }

    /**
     * Get the datatype value. As defined in the setDataType value doc.
     *
     * @see com.caiso.soa.framework.ejb.connector.IConnectorAdapter#getDataType()
     */
    public String getDataType() {
        return dataType;
    }

    /**
     * Provide an onMessage method for when the payload is an xml message.
     *
     * @param pService WSDL Service name
     * @param pPayload XML Data payload as String
     *
     * @return  XML Data, repsonse
     *
     * @throws OutputDataTypeException
     *
     * @see com.caiso.soa.framework.ejb.connector.IConnectorAdapter#onMessage(java.lang.String,
     *      java.lang.String)
     */
    public String onMessage(String pService, String pPayload, Map pMessageHeader)
        throws ConnectorException, OutputDataTypeException {
        //for now this is a no-op since you may not want to implement this but implement the object version of the method.
        throw new UnsupportedOperationException(
            "onMessage(String pService, String pPayload) not supported for this connector");
    }

    /**
     * Provide an onMessage implementation when the payload is an jaxb object model
     *
     * @param pService WSDL Service name
     * @param pPayload XML Data payload as JAXB object model
     *
     * @return  XML Data, repsonse
     *
     * @throws OutputDataTypeException
     *
     * @see com.caiso.soa.framework.ejb.connector.IConnectorAdapter#onMessage(java.lang.String,
     *      java.lang.Object)
     */
    public Object onMessage(String pService, Object pPayload, Map pMessageHeader)
        throws ConnectorException, OutputDataTypeException {
        //for now this is a no-op since you may not want to implement this but implement the xml version of the method.
        throw new UnsupportedOperationException(
            "onMessage(String pService, Object pPayload) not supported for this connector");
    }
}
