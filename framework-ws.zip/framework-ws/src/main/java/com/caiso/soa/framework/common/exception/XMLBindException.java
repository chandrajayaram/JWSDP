/*
 * Copyright (c) 2006 California ISO. All rights reserved.
 */
package com.caiso.soa.framework.common.exception;

/**
 * Generic exception for XML Binding Exceptions
 *
 * @author <a href="mailto:mpope@caiso.com?Subject=JAVADOC - Question about ${package_name}.${file_name}">
 *         Mark Pope</a>
 * @version $$Revision:  $$ $$Date:  $$
 * @Copyright (c) California ISO 2006
 */
public class XMLBindException extends BaseException {
    private static final long serialVersionUID = 4406026297814976983L;

    /**
     * Creates a new XMLBindException object.
     */
    public XMLBindException() {
        super();
    }

    /**
     * Creates a new XMLBindException object.
     *
     * @param pString exception message
     */
    public XMLBindException(String pString) {
        super(pString);
    }

    /**
     * Creates a new XMLBindException object.
     *
     * @param pException exception message
     */
    public XMLBindException(Exception pException) {
        super(pException);
    }

    /**
     * Creates a new XMLBindException object.
     *
     * @param pString exception message
     * @param pThrowable root exception
     */
    public XMLBindException(String pString, Throwable pThrowable) {
        super(pString, pThrowable);
    }
}
