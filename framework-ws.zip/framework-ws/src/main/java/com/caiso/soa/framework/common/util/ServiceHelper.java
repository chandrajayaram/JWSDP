/**
 * $Header: //depot/Perforce Depot/Market Systems/Applications/Integration-WS/Framework/src/java/com/caiso/soa/framework/common/util/ServiceHelper.java#5 $
 * $Revision: #5 $
 * $Date: 2014/06/19 $
 * $Author: iloh $
 */
package com.caiso.soa.framework.common.util;

import java.lang.reflect.Method;
import java.net.URL;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;

import org.apache.log4j.Logger;

import com.caiso.soa.common.constants.ConnectorConstants;
import com.caiso.soa.framework.common.Constants;


/*
 * A convience utility that wrappers mime header interrogation and locates
 * System properties.
 *
 * A mime header of the SOAPMessage contains SOAPAction. This value is used to
 * locate other service related values via System properties.
 *
 * System properties are loaded from conf/xxx.properties when JBoss starts up.
 *
 * @author <a href="mailto:mpope@caiso.com?Subject=JAVADOC - Question about
 * com.caiso.soa.framework.common.ServiceHelper.java"> Mark Pope </a>
 *
 * @version $Revision: #5 $ $Date: 2014/06/19 $
 *
 * @Copyright (c) California ISO 2005
 *
 */
public class ServiceHelper {
    private static Logger logger = Logger.getLogger(ServiceHelper.class);
    /**
     * serviceName is required and must be gotten successfully either from the constructor
     * parameter or from a property file.
     */
    private String service;
    private static Set<String> documentStyleServices = new HashSet<>();  
    private static final String CONTENT_TYPE  = "Content-Type";
    private static final String MTOM_TYPE  = "application/xop+xml";
    
	private boolean isRequestMtom;
	
	public static final String DEFAULT_CONNECTOR = "default" + Constants.CONNECTOR;
	public static final String DEFAULT_CONNECTOR_BEAN = "default" + Constants.CONNECTOR_BEAN;
    
	
	private String actionValue = null;
	private SOAPMessage soapMessage;
    
	public ServiceHelper(String pService) {
    	setService(pService);
        if (logger.isDebugEnabled()) {
            logger.debug("[init(String)] - Properties: ");
            logger.debug(toString());
        }
    }

    
    /**
     * Creates a utility for providing information about a service.  This
     * implementation depends on the existence of a SOAP 1.1 feature, the
     * inclusion of an HTTP header element SOAPAction. The SOAPAction tag
     * includes the service endpoint. This feature has been removed from SOAP
     * 1.2 but several vendors still include it.
     *
     * @param pMsg - Message that includes info of service.
     *
     * @throws SOAPException - fails if SOAP 1.1 SOAPStation tag is missing
     */
    public ServiceHelper(URL pMsg) throws SOAPException {
    	
    		String actionValue = pMsg.toString().replaceAll("\"", "");
    		if (logger.isDebugEnabled()) {
    			logger.debug("[ServiceHelper] - SoapAction = " + actionValue);
    		}
    		if (actionValue == null) {
	            throw new SOAPException("SOAPAction not found in SOAPMessage.");
    		}
    		setServiceNameFromSoapAction(actionValue);
    }
    /**
     * Creates a utility for providing information about a service.  This
     * implementation depends on the existence of a SOAP 1.1 feature, the
     * inclusion of an HTTP header element SOAPAction. The SOAPAction tag
     * includes the service endpoint. This feature has been removed from SOAP
     * 1.2 but several vendors still include it.
     *
     * @param pMsg - Message that includes info of service.
     *
     * @throws SOAPException - fails if SOAP 1.1 SOAPStation tag is missing
     */
    public ServiceHelper(SOAPMessage pMsg, String wsdlStyleDocument)
        throws SOAPException {
    	
    	soapMessage = pMsg; 
    	
    	String value = System.getProperty("wsdl.style.document");
		if(value!=null && documentStyleServices.isEmpty()){
			documentStyleServices.addAll(Arrays.asList(value.split(",")));
		}
		
    	if (pMsg.getMimeHeaders() != null) {
        	actionValue =
        		pMsg.getMimeHeaders().getHeader(Constants.HEADER_SOAP_ACTION)[0];
    	}

        if (actionValue == null || actionValue.length() == 0) {
            throw new SOAPException("SOAPAction not found in SOAPMessage.");
        } else {
        	actionValue = actionValue.replaceAll("\"", "");
        }

        if (logger.isDebugEnabled()) {
            logger.debug("[ServiceHelper] - SoapAction = " + actionValue);
        }
        
        setServiceNameFromSoapAction(actionValue);
        setRequestMtom(checkIsRequestMtom(pMsg));
    }
    
    private void setServiceNameFromSoapAction(String actionValue)
    	throws SOAPException {
    	 int index= actionValue.lastIndexOf('/');
    	 service = actionValue.substring(++index);
    	 
    	 setService(service);

         if (logger.isDebugEnabled()) {
             logger.debug("[setServiceNameFromSoapAction] - service = " + service);
         }

         if ((service == null) || (service.length() == 0)) {
             throw new SOAPException(
                 "Retrieve Service Name from the Soap Action failed Soap Action: " + actionValue);
         }
         
         if (logger.isDebugEnabled()) {
             logger.debug("[setServiceNameFromSoapAction] - Properties: ");
             logger.debug(toString());
         }
    }


    /**
     * Gets the service name.
     *
     * @return Service Name
     */
    public String getService() {
        return service;
    }


    /**
     * Get the soap action from for this service, used by the SOAClient.
     *
     * @return Soap Action associated with the serviceName. SOAClient requires
     *         this one.
     *
     * @see com.caiso.soa.framework.common.soaclient
     */
    public String getSoapAction() {
        return actionValue;
    }

    /**
     * If this service is with attachment then return true.
     *
     * @return true if is with attachment else false
     * @deprecated Replaced by isRequestWithAttachment
     */
    public boolean isWithAttachement() {
        return isRequestWithAttachment();
    }
    
    
    public boolean isRequestWithAttachment(){
    	return true;
    }
    
    public boolean isResponseWithAttachment(){
    	return false;
    }
    

    /**
     * Report all properties
     *
     * @see java.lang.Object#toString()
     */
    public String toString() {
        if ((service == null) || (service.length() == 0)) {
            return "Service not set";
        }
        
        StringBuffer buffer = new StringBuffer();
        Method[] methods = this.getClass().getMethods();
        buffer.append("\n[ServiceHelper:");
         
        for (int i = 0; i < methods.length; i++){
        	if ((methods[i].getName().startsWith("get") && 
        		!methods[i].getName().equals("getClass")))
        	{
        		buffer.append("\n\t" + methods[i].getName().substring(3));
        		try {
					buffer.append(": " + methods[i].invoke(this, new Object[]{}));
				} catch (Exception e) {
					// do nothing
				}
        	} else if (methods[i].getName().startsWith("is")){
        		buffer.append("\n\t" + methods[i].getName().substring(2));
        		try {
					buffer.append(": " + methods[i].invoke(this, new Object[]{}));
				} catch (Exception e) {
					// do nothing
				}
        	}
        }
        buffer.append("]");
        return buffer.toString();
    }

   


    /**
     *  Allows service name to be overwritten
     *
     * @param pService Service Name
     */
    private void setService(String pService) {
        service = pService;
    }
    
  

    /**
     * load service properties file if it exists from classpath.!
     */

    /* (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    public boolean equals(Object pHelper) {
        
    	if (!(pHelper instanceof ServiceHelper)) {
    		return false;
    	}
    	ServiceHelper helper = (ServiceHelper)pHelper;
        Method[] thisMethods = this.getClass().getMethods();
        Method[] thatMethods = helper.getClass().getMethods();
         
        for (int i = 0; i < thisMethods.length; i++){
        	Method thisMethod = thisMethods[i];
        	if ((thisMethod.getName().startsWith("get") || 
        	    thisMethod.getName().startsWith("is")) && 
        		!thisMethod.getName().equals("getClass"))
        	{
        		try {
        			Method thatMethod = null;
        			for (int j = 0; j < thatMethods.length; j++){
        				if(thatMethods[j].getName().equals(thisMethod.getName())){
        					thatMethod = thatMethods[j];
        					break;
        				}
        			}
        			
					Object thisValue = thisMethod.invoke(this, new Object[]{});
					Object thatValue = thatMethod.invoke(this, new Object[]{});
					 
					 if (!thisValue.equals(thatValue)) {
						 return false;
        			}
				} catch (Exception e) {
					// do nothing
				}
        	}
        }
        return true;
    }
    
    /**
     * This method checks whether the incoming request is a mtom request and also
     * sets the mtom flag to true which is used while generating response to
     * generate mtom response.
     * @param pMsg
     * @return boolean 
     * @throws SOAPException
     */
    public boolean checkIsRequestMtom(SOAPMessage pMsg) throws SOAPException {
    	boolean mtomRequest = false;
    	if (pMsg.getMimeHeaders() != null) {
    		if(pMsg.getMimeHeaders().getHeader(CONTENT_TYPE)[0].contains(MTOM_TYPE)){
    			mtomRequest = true;
    		}
    	}
    	return mtomRequest;
    }
    
    public boolean isRequestMtom() {
		return isRequestMtom;
	}
	public void setRequestMtom(boolean isRequestMtom) {
		this.isRequestMtom = isRequestMtom;
	}
	public boolean isResponseMtom() {
		return false;
	}


	public String getJAXBContextPath() {
		// TODO Auto-generated method stub
		return "com.caiso.soa._2006_06_13.standardoutput";
	}


	public boolean isValidateRequest() {
		// TODO Auto-generated method stub
		return false;
	}


	public String getRequestPartName() {
		// TODO Auto-generated method stub
		return null;
	}


	public String getResponseElementName() {
		// TODO Auto-generated method stub
		return null;
	}


	public String getRequestElementNamespace() {
		// TODO Auto-generated method stub
		return null;
	}


	public String getResponseElementNamespace() {
		// TODO Auto-generated method stub
		return null;
	}


	public String getWSDLStyle() {
		if(!documentStyleServices.contains(service)){
			return ConnectorConstants.STYLE_RPC;	
		}else{
			return ConnectorConstants.STYLE_DOCUMENT;
		}
	}


	public int getMaxAttachmentSize() {
		// TODO Auto-generated method stub
		return 0;
	}


	public String getServiceURI() {
		// TODO Auto-generated method stub
		return null;
	}


	public String getRequestElementName() {
		// TODO Auto-generated method stub
		return null;
	}


	
}
