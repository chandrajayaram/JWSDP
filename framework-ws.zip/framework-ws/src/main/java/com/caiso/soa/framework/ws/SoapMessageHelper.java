/**
 * $Header: //depot/Perforce Depot/Market Systems/Applications/Integration-WS/Framework/src/java/com/caiso/soa/framework/common/util/SoapMessageHelper.java#9 $
 * $Revision: #9 $
 * $Date: 2014/07/23 $
 * $Author: iloh $
 */
package com.caiso.soa.framework.ws;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;
import java.util.UUID;

import javax.activation.DataHandler;
import javax.xml.bind.JAXBException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.soap.AttachmentPart;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.Name;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPBodyElement;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPFactory;
import javax.xml.soap.SOAPFault;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPHeaderElement;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.caiso.soa.common.util.BinaryDataSource;
import com.caiso.soa.common.util.JAVAUtil;
import com.caiso.soa.framework.common.Constants;
import com.caiso.soa.framework.common.OutputDataTypeConstants;
import com.caiso.soa.framework.common.exception.OutputDataTypeException;
import com.caiso.soa.framework.common.exception.XMLBindException;
import com.caiso.soa.framework.common.util.ServiceHelper;
import com.caiso.soa.framework.common.util.XMLBindUtility;

/**
 * Replaces many of the methods in SoapUtility. This helper consolidates
 * functionality for creating soap messages. It has the intelligence to know
 * when a message needs to be part of the soap body (ISO Standard WSDL's) and
 * when it needs to be an attachment because it is too big to be in the soap
 * body (ISO Large Message WSDL's). When using the constructor that takes a SOAP
 * Message an assumption is made that you are processing for a response message,
 * when any of the other constructors are used it assumes that the helper was
 * created to process a request.
 * <p>
 * Therefore when the helper is in response mode the getSoapMessageContent will
 * retrieve the content of the message whether in the soap body or the
 * attachment and return it to the caller as a string. When the helper is in the
 * request mode the createSoapMessage method will create a message from the
 * passed in string putting the content into the message either in the body or
 * as an attachment.
 * <p>
 * The ISO Service Jars are required to be in the classpath so that the service
 * helper can be created for the serviceName. The property files that are part
 * of the service jars are necessary for the attachment logic to be transparent
 * to the calling process.
 * 
 * Known Subclasses:
 * 
 * @see com.caiso.com.caiso.soa.framework.ws.util.RequestMessageHelper
 * @see com.caiso.com.caiso.soa.framework.ws.util.ResponseMessageHelper
 * 
 * 
 * @author tflora
 *
 */
public class SoapMessageHelper {
	private static String XMLNS = "xmlns";
	private static final String EVENT_LOG = "EventLog";

	private static final String ATTACHMENT = "Attachment";

	private static final String SOAP_FAULT_STRING_EXCEPTION_OCCURED = "Standard Output Exception Occured";

	private static final String TEXT_XML = "text/xml";

	public static final String CONTENT_TYPE = "Content-Type";
	public static final String SOAP_ACTION = "SOAPAction";
	private static final String CLOSE = "Close";
	private static final String CONNECTION = "Connection";

	private static final String FAULT_HEADER = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><e:Envelope xmlns:e=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"   xmlns:d=\"http://www.w3.org/2001/XMLSchema\" xmlns:caiso=\"http://www.caiso.com/soa/2006-06-13/StandardOutput.xsd\"> <e:Body> <e:Fault xmlns:ns0=\"http://schemas.xmlsoap.org/wsdl/soap/\">";
	private static final String FAULT_CODE_HEADER = "<faultcode>";
	private static final String FAULT_CODE_FOOTER = "</faultcode> ";
	private static final String FAULT_NAMESPACE = "ns0";
	private static final String FAULT_STRING_HEADER = "<faultstring>";
	private static final String FAULT_STRING_FOOTER = "</faultstring>";
	private static final String FAULT_DETAIL_HEADER = "<detail>";
	private static final String FAULT_DETAIL_FOOTER = "</detail>";
	private static final String FAULT_FOOTER = "</e:Fault> </e:Body> </e:Envelope>";

	/**
	 * MTOM specific constants
	 */
	private static final String ATTACHMENT_CONTENT_ID = "cid:";
	private static final String MTOM_PAYLOAD = "payload";
	private static final String XOP_LOCAL_NAME = "Include";
	private static final String XOP_PREFIX = "xop";
	private static final String HREF = "href";
	private ServiceHelper serviceHelper = null;
	private MimeHeaders headers = new MimeHeaders();
	private MessageFactory factory = null;

	private SOAPFactory soapFactory = null;

	private static final Logger logger = Logger.getLogger(SoapMessageHelper.class);

	/*
	 * Mode is -1 before a constructor is called. Depending on the constructor
	 */
	public static final int MODE_REQUEST = 0;
	public static final int MODE_RESPONSE = 1;
	public static final int MODE_INVALID = -1;
	protected int mode = MODE_INVALID;
	public String MODE_REQUEST_LABEL = "Request";
	public String MODE_RESPONSE_LABEL = "Response";
	public String MODE_INVALID_LABEL = "Invalid";
	private SOAPMessage soapMessage;

	/**
	 * Hide the default constructor and make all other constructors protected so
	 * that the subclasses must be used to instantiate a message helper.
	 *
	 */
	public SoapMessageHelper() {

	}

	/**
	 * Create a soapMessageHelper.
	 *
	 * @param serviceName
	 *            - The serviceName to use when creating the request
	 *            SOAPMessage.
	 * @throws SOAPException
	 *             - Bubbled up from the ServiceHelper
	 */
	public SoapMessageHelper(String serviceName) {
		this(new ServiceHelper(serviceName));
	}

	/**
	 * Create a soapMessageHelper
	 * 
	 * @param serviceHelper
	 *            - The serviceHelper to use when creating the request
	 *            SOAPMessage.
	 * @throws SOAPException
	 *             - Bubbled up from the ServiceHelper
	 */
	public SoapMessageHelper(ServiceHelper serviceHelper) {
		this.serviceHelper = serviceHelper;
	}

	/**
	 * Create a soapMessageHelper in expectation of creating a SOAPMessage.
	 * 
	 * @param serviceHelper
	 *            - The serviceHelper to use when creating the request
	 *            SOAPMessage.
	 * @param headers
	 *            - The MIMEHeaders object to use when creating the request
	 *            SOAPMessage
	 * @throws SOAPException
	 *             - Bubbled up from the ServiceHelper
	 */
	protected SoapMessageHelper(ServiceHelper serviceHelper, MimeHeaders headers) {
		this(serviceHelper);
		this.headers = headers;
	}

	/**
	 * Create a soapMessageHelper in expectation of creating a SOAPMessage.
	 * 
	 * @param serviceName
	 *            - The serviceName to use when creating the request
	 *            SOAPMessage.
	 * @param headers
	 *            - The MIMEHeaders object to use when creating the request
	 *            SOAPMessage
	 * @throws SOAPException
	 *             - Bubbled up from the ServiceHelper
	 */
	protected SoapMessageHelper(String serviceName, MimeHeaders headers) {
		this(new ServiceHelper(serviceName), headers);
	}

	public SoapMessageHelper(SOAPMessage pInMessage) {
		this.soapMessage = pInMessage;
	}

	private String getAttachmentLocalName() {
		String result = (mode == MODE_REQUEST) ? serviceHelper.getRequestPartName()
				: serviceHelper.getRequestPartName();
		return result;
	}

	private SOAPFactory getSoapFactory() throws SOAPException {
		if (soapFactory == null) {
			soapFactory = SOAPFactory.newInstance();
		}
		return soapFactory;
	}

	protected MessageFactory getMessageFactory() throws SOAPException {
		if (factory == null) {
			factory = MessageFactory.newInstance();
		}
		return factory;
	}

	public String getMode() {
		switch (mode) {
		case MODE_REQUEST:
			return MODE_REQUEST_LABEL;
		case MODE_RESPONSE:
			return MODE_RESPONSE_LABEL;
		default:
			return MODE_INVALID_LABEL;
		}
	}

	/**
	 * get the serviceName associated with this messageHelper
	 * 
	 * @return
	 */
	public String getServiceName() {
		return serviceHelper.getService();
	}

	public String getSoapAction() {
		return serviceHelper.getSoapAction();
	}

	public String getPartName() {
		if (mode == MODE_REQUEST) {
			return serviceHelper.getRequestPartName();
		} else {
			return serviceHelper.getRequestPartName();
		}
	}

	public String getElementName() {
		if (mode == MODE_REQUEST) {
			return serviceHelper.getRequestPartName();
		} else {
			return serviceHelper.getResponseElementName();
		}
	}

	public String getElementNameSpace() {
		if (mode == MODE_REQUEST) {
			return serviceHelper.getRequestElementNamespace();
		} else {
			return serviceHelper.getResponseElementNamespace();
		}
	}

	/**
	 * Add header properties to the MIME headers object. The headers object is
	 * used in the creation of the SOAPMessage when the
	 * <code>createSOAPMessage</code> method is called.
	 * 
	 * @param headerName
	 *            - Header name to add
	 * @param value
	 *            - The value for the new header.
	 */
	public void addHeader(String headerName, String value) {
		headers.addHeader(headerName, value);
	}

	/**
	 * Remove a header property from the MIME headers object. The headers object
	 * is used in the creation of the SOAPMessage when the
	 * <code>createSOAPMessage</code> method is called.
	 * 
	 * @param headerName
	 *            - Header name to remove
	 */
	public void removeHeader(String headerName) {
		headers.removeHeader(headerName);
	}

	/**
	 * Remove all the header properties from the MIME header object. The headers
	 * object is used in the creation of the SOAPMessage when the
	 * <code>createSOAPMessage</code> method is called.
	 */
	public void removeAllHeaders() {
		headers.removeAllHeaders();
	}

	/**
	 * Used internally to create a new soap message where the data for the
	 * message is contained in the soap body of the message
	 * 
	 * @param data
	 *            - The data to use in the soap body.
	 * @return - A SOAPMessage object.
	 * @throws SOAPException
	 *             - Bubbled up from the SAAJ API.
	 */
	private SOAPMessage createNewSoapMessage(String data) throws SOAPException {
		SOAPMessage msg;
		if (logger.isDebugEnabled()) {
			logger.debug("[createNewSoapMessage] - Started!");
		}

		try {
			headers.addHeader(CONTENT_TYPE, TEXT_XML);
			headers.addHeader(CONNECTION, CLOSE);
			headers.addHeader(SOAP_ACTION, serviceHelper.getSoapAction());

			/*
			 * Start preparation of the string. Strip the xml header if it
			 * exists Also add the operation name and namespace if this is rpc
			 * style
			 */
			StringBuffer s = new StringBuffer();
			if (data != null && data.length() > 0) {
				s.append(data.substring(data.indexOf("?>") + 2));
			} else {
				s.append(data);
			}

			if (serviceHelper.getWSDLStyle().equalsIgnoreCase(Constants.STYLE_RPC)) {
				s.insert(0, "<" + getServiceName() + " xmlns=\"" + serviceHelper.getSoapAction() + "\">");
				s.append("</" + getServiceName() + ">");
			}
			/* Add the soap env header and footer */
			s.insert(0, Constants.SOAP_HEADER);
			s.append(Constants.SOAP_FOOTER);

			msg = getMessageFactory().createMessage(headers, new ByteArrayInputStream(s.toString().getBytes()));
			/*
			 * Add a header element so that if there are headers that need to be
			 * added to this message the headerelement exists
			 */
			msg.getSOAPPart().getEnvelope().addHeader();
		} catch (IOException e) {
			throw new SOAPException("Data could not be read from byte input stream", e);
		}
		return msg;

	}

	/**
	 * Gets a soap header element by elementname, nameSpace
	 * 
	 * @param msg
	 *            - the message to get the header element from
	 * @param elementName
	 *            - the elementName
	 * @param prefix
	 *            - the prefix
	 * @param nameSpace
	 *            - the fully qualified namespace
	 * @return - the SOAPHeaderElement
	 * @throws SOAPException
	 */
	public SOAPHeaderElement getHeaderElement(SOAPMessage msg, String elementName, String prefix, String nameSpace)
			throws SOAPException {
		SOAPHeader header = msg.getSOAPPart().getEnvelope().getHeader();

		/* If there is no header then just return null */
		if (header == null) {
			return null;
		}

		/* Create the name object that defines the node */
		Name name = getSoapFactory().createName(elementName, prefix, nameSpace);
		Iterator list = header.getChildElements(name);
		/* Get the first element identified by the name */
		if (list.hasNext()) {
			return (SOAPHeaderElement) list.next();
		} else {
			return null;
		}
	}

	public SOAPElement getChildElement(SOAPHeaderElement header, String elementName, String prefix, String nameSpace)
			throws SOAPException {
		/* Just in case the passed in a null header. */
		if (header == null) {
			return null;
		}
		/* Create the name object that defines the node */
		Name name = getSoapFactory().createName(elementName, prefix, nameSpace);
		Iterator childElement = header.getChildElements(name);
		/* return the first element identified by elementName */
		if (childElement.hasNext()) {
			return (SOAPElement) childElement.next();
		} else {
			return null;
		}
	}

	public SOAPElement getChildElement(SOAPHeaderElement header, String elementName) throws SOAPException {
		/* Just in case the passed in a null header. */
		if (header == null) {
			return null;
		}
		/* Create the name object that defines the node */
		Name name = getSoapFactory().createName(elementName);
		Iterator childElement = header.getChildElements(name);
		/* return the first element identified by elementName */
		if (childElement.hasNext()) {
			return (SOAPElement) childElement.next();
		} else {
			return null;
		}
	}

	/**
	 * Get Message Properties and add to a tree map for delivery to connector.
	 * 
	 * @param msg
	 * @return
	 * @throws SOAPException
	 */
	public Map getMessageProperties(SOAPMessage msg) throws SOAPException {
		TreeMap result = new TreeMap();

		if (logger.isDebugEnabled()) {
			logger.debug("[getMessageProperties] - Get the Security Header Element");
		}
		/*
		 * For now just get UserName from security Token, In the future other
		 * message properties can be added for delivery to connector
		 */
		String userName = getUserTokenValue(msg);
		if (userName != null) {
			result.put(Constants.CAISO_WS_USER_NAME, userName);
		}

		String hashValue = getAttachmentHashValue(msg);
		if (hashValue != null) {
			result.put(Constants.HASH_VALUE, hashValue);
		}

		if (logger.isDebugEnabled()) {
			logger.debug("[getMessageProperties] - UserName = " + userName);
		}

		// Store of the SOAPAction
		String soapAction = null;
		if (!result.containsKey(SoapMessageHelper.SOAP_ACTION)) {
			soapAction = msg.getMimeHeaders().getHeader(SoapMessageHelper.SOAP_ACTION)[0].replaceAll("\"", "");
			if (soapAction != null) {
				result.put(SOAP_ACTION, soapAction);
			} else {
				logger.warn("Could not retrieve " + SoapMessageHelper.SOAP_ACTION + " from SOAP Message headers");
			}
		}

		logger.debug("[getMessageProperties] - " + SOAP_ACTION + " = " + soapAction);

		/*
		 * Pass the envelope as a messageProperty, added for docAttach effort.
		 * Yes this seems to break the previously held KISS method for
		 * connectors, but we need this and there is no time to figure out a
		 * user friendly way to get all header and nameSpace values.
		 */

		SOAPEnvelope envelope = msg.getSOAPPart().getEnvelope();
		if (envelope != null) {
			result.put(Constants.SOAP_ENVELOPE, envelope);
		}

		return result;
	}

	public String getUserTokenValue(SOAPMessage msg) throws SOAPException {
		if (logger.isDebugEnabled()) {
			logger.debug("[getUserTokenValue] - Started");
		}
		String namespace = System.getProperty(Constants.PROP_CAISO_WSHEADER_NS, Constants.CAISO_WS_NAMESPACE);
		return getHeaderValue(msg, Constants.CAISO_WS_HEADER_NAME, Constants.CAISO_WS_USER_TOKEN_NAME,
				Constants.CAISO_WS_PREFIX, namespace, Constants.CAISO_WS_USER_NAME);
	}

	public String getAttachmentHashValue(SOAPMessage msg) throws SOAPException {
		if (logger.isDebugEnabled()) {
			logger.debug("[getAttachmentHashValue] - Started");
		}
		String namespace = System.getProperty(Constants.PROP_ATTACHMENT_HASH_NS,
				Constants.HTTP_WWW_CAISO_COM_MRTU_SOA_SCHEMAS_2005_09_ATTACHMENTHASH);
		SOAPHeaderElement header = getHeaderElement(msg, Constants.ATTACHMENT_HASH_NAME, Constants.NS1, namespace);

		SOAPElement element = null;
		element = getChildElement(header, Constants.HASH_VALUE, Constants.NS1, namespace);

		if (element == null) {
			element = getChildElement(header, Constants.HASH_VALUE);

		}
		if (element == null) {
			return null;
		}
		return element.getValue();
	}

	private String getStandardAttachmentInforValue(SOAPMessage msg, String value) throws SOAPException {
		if (logger.isDebugEnabled()) {
			logger.debug("[getStandardAttachmentInforValue] - Started");
		}
		String nameSpace = System.getProperty(Constants.PROP_STANDARD_ATTACHMENT_NS,
				Constants.HTTP_WWW_CAISO_COM_SOA_2005_06_21_STANDARD_ATTACHMENT_INFOR_XSD);
		return getHeaderValue(msg, Constants.STANDARD_ATTACHMENT_INFOR, ATTACHMENT, Constants.NS2, nameSpace, value);
	}

	private String getHeaderValue(SOAPMessage msg, String headerName, String childName, String headerPrefix,
			String headerNameSpace, String value) throws SOAPException {
		if (logger.isDebugEnabled()) {
			logger.debug("[getHeaderValue] - Started");
		}
		/* needed to create name objects for lookup of elements */
		SOAPFactory soapFactory = SOAPFactory.newInstance();
		/*
		 * The ultimate goal is to find a soapElement that represents the value
		 * param
		 */
		SOAPElement valueElement = null;

		/* Get the soap Header Object from the message */
		SOAPHeader header = msg.getSOAPPart().getEnvelope().getHeader();

		/* If there is no soap header then just return null. */
		if (header == null) {
			if (logger.isDebugEnabled()) {
				logger.debug("[getHeaderValue] - No Header on the message for value: " + value);

			}
			return null;
		}

		if (logger.isDebugEnabled()) {
			logger.debug("[getHeaderValue] - Create Name for attachment information");
		}

		/* Create the name object that defines the node requested */
		Name name = soapFactory.createName(headerName, headerPrefix, headerNameSpace);
		if (logger.isDebugEnabled()) {
			logger.debug("[getHeaderValue] - get Element: " + headerName);
		}

		/* Get the Node for the name */
		Iterator list = header.getChildElements(name);
		if (list.hasNext()) {
			SOAPHeaderElement element = (SOAPHeaderElement) list.next();
			if (logger.isDebugEnabled()) {
				logger.debug("[getHeaderValue] - Header Element Found By Name: " + element.getElementName());
			}
			/* Create a name object that represents the attachment node */
			name = soapFactory.createName(childName, headerPrefix, headerNameSpace);
			Iterator j = element.getChildElements(name);
			/* Get the child Node */
			if (j.hasNext()) {
				SOAPElement soapElement = (SOAPElement) j.next();
				if (logger.isDebugEnabled()) {
					logger.debug("[getHeaderValue] - Child Element Found By Name: " + soapElement.getElementName());
				}
				/* Create a name object that represents the value node */
				name = soapFactory.createName(value, headerPrefix, headerNameSpace);
				Iterator k = soapElement.getChildElements(name);
				/* Get the Value Node */
				if (k.hasNext()) {
					valueElement = (SOAPElement) k.next();
					if (logger.isDebugEnabled()) {
						logger.debug("[getHeaderValue] - Found Value Element for: " + value);
						logger.debug("[getHeaderValue] - name: " + valueElement.getElementName());
						logger.debug("[getHeaderValue] - Value: " + valueElement.getValue());

					}
				}

			}
		}

		/*
		 * If we successfully got the valueElement then return the value else
		 * null
		 */
		if (valueElement != null) {
			return valueElement.getValue();
		} else {
			return null;
		}
	}

	/**
	 * Get a hash value from the byte array
	 * 
	 * @param data
	 *            - byte array of data
	 * @return - the hash value
	 * @throws NoSuchAlgorithmException
	 * @throws UnsupportedEncodingException
	 */
	public String getSecureHash(byte[] data) throws NoSuchAlgorithmException, UnsupportedEncodingException {
		return JAVAUtil.getMessageDigest(data, Constants.SHA_1);
	}


	/**
	 * Used internally to create a new soap message where the data for the
	 * message is in an attachment. A Header property is also added to the
	 * header that defines the attachment.
	 * 
	 * @param data
	 *            - The data to use in the attachment
	 * @param compressed
	 *            - if true the data will be compressed and uue encoded.
	 * @return - A SOAPMessage object.
	 * @throws SOAPException
	 *             - Bubbled up from the SAAJ API.
	 */
	public SOAPMessage createNewSoapMessageWithAttachment(String data, boolean compressed) throws SOAPException {
		SOAPMessage msg;

		try {
			if (logger.isDebugEnabled()) {
				logger.debug("[createNewSoapMessageWithAttachment] - Started");
			}
			/*
			 * Compress the data into a byte array.
			 */

			byte[] barray;
			if (compressed) {
				if (logger.isDebugEnabled()) {
					logger.debug("[createNewSoapMessageWithAttachment] - Compressing Data");
				}
				barray = JAVAUtil.compressBase64XML(data).getBytes();
			} else {
				if (logger.isDebugEnabled()) {
					logger.debug("[createNewSoapMessageWithAttachment] - Using data Uncompressed");
				}
				barray = data.getBytes();
			}

			/*
			 * Use the Secure Hash Algorithm to create a hash that signs the
			 * data. The reason we need this is SST cannot validate the data
			 * when it is in an attachment. Therfore we are digitally signing
			 * the data ourselves and verifying it on the inbound side of the
			 * transaction.
			 */
			String digestValue = getSecureHash(barray);

			SOAPFactory soapFactory = SOAPFactory.newInstance();

			headers.addHeader(CONNECTION, CLOSE);
			headers.addHeader(SOAP_ACTION, serviceHelper.getSoapAction());
			headers.addHeader(CONTENT_TYPE, TEXT_XML);
			String bodyStr = getAttachmentBody();
			ByteArrayInputStream inputStream = new ByteArrayInputStream(bodyStr.getBytes());

			msg = getMessageFactory().createMessage(headers, inputStream);

			SOAPHeader header = msg.getSOAPPart().getEnvelope().addHeader();

			/*
			 * Create a soap header element to add these properties to.
			 */
			String nameSpace = System.getProperty(Constants.PROP_ATTACHMENT_HASH_NS,
					Constants.HTTP_WWW_CAISO_COM_MRTU_SOA_SCHEMAS_2005_09_ATTACHMENTHASH);
			Name name = soapFactory.createName(Constants.ATTACHMENT_HASH, Constants.NS1, nameSpace);
			SOAPHeaderElement attachment_Hash_Element = header.addHeaderElement(name);

			/*
			 * Set the actor for this element
			 */
			attachment_Hash_Element.setActor(Constants.HTTP_SCHEMAS_XMLSOAP_ORG_SOAP_ACTOR_NEXT);
			attachment_Hash_Element.setMustUnderstand(false);

			/*
			 * Set the hash value into the header element
			 */
			SOAPElement hashValueElement = attachment_Hash_Element.addChildElement(Constants.HASH_VALUE, Constants.NS1);
			hashValueElement.addTextNode(digestValue);

			/*
			 * Create a name for the standard attachment information object.
			 */
			name = soapFactory.createName(Constants.STANDARD_ATTACHMENT_INFOR, Constants.NS1,
					Constants.STANDARD_ATTACHMENT_INFOR_NAMESPACE);

			/*
			 * Add another header element to hold the standard attachment
			 * information
			 */
			SOAPHeaderElement standard_Attachment_Element = header.addHeaderElement(name);
			attachment_Hash_Element.setActor(Constants.HTTP_SCHEMAS_XMLSOAP_ORG_SOAP_ACTOR_NEXT);

			/*
			 * If the mustUnderstand attribute is on, the actor who receives the
			 * SOAPHeaderElement must process it correctly. This ensures, for
			 * example, that if the SOAPHeaderElement object modifies the
			 * message, that the message is being modified correctly. Since
			 * there will be no modification of the message and the Large
			 * Message Implementation guideline tells us to set this to false we
			 * will do so.
			 */
			attachment_Hash_Element.setMustUnderstand(false);

			/*
			 * Create the attachment element and prepare it for the attachment.
			 */
			SOAPElement attachment_Element = standard_Attachment_Element.addChildElement(ATTACHMENT);
			SOAPElement id_Element = attachment_Element.addChildElement(Constants.ID);
			id_Element.addTextNode(Constants._1);

			/*
			 * Set a flag to show that the message attachment is compressed.
			 */
			SOAPElement flag_Element = attachment_Element.addChildElement(Constants.COMPRESS_FLAG);
			flag_Element.addTextNode(Constants.YES);

			/*
			 * Specify the compression method so that the end process knows how
			 * to decompress it.
			 */
			SOAPElement method_Element = attachment_Element.addChildElement(Constants.COMPRESS_METHOD);
			method_Element.addTextNode(Constants.GZIP);

			addAttachmentToMessage(msg, barray);

		} catch (Exception e) {
			throw new SOAPException(e);
		}
		return msg;
	}

	/**
	 * Used internally to create a new mtom soap message where the data for the
	 * message is contained in an attachment. A Header property is also added to
	 * the header that defines the attachment. For now we use base64Binary
	 * encoding for data compression
	 * 
	 * @param data
	 *            - The data to use in the attachment
	 * @param compressed
	 *            - if true the data will be compressed and uue encoded.
	 * @return - A SOAPMessage object.
	 * @throws SOAPException
	 *             - Bubbled up from the SAAJ API.
	 * @throws Exception
	 */

	public SOAPMessage createNewSoapMessageWithMTOMAttachment(String data, boolean compressed) throws SOAPException {
		SOAPMessage msg;
		String attachmentId;
		try {
			if (logger.isDebugEnabled()) {
				logger.debug("[createNewSoapMessageWithMTOMAttachment] - Started");
			}
			/*
			 * Compress the data into a byte array.
			 */

			byte[] barray;
			if (compressed) {
				if (logger.isDebugEnabled()) {
					logger.debug("[createNewSoapMessageWithMTOMAttachment] - Compressing Data");
				}
				barray = JAVAUtil.compressBase64XML(data).getBytes();
			} else {
				if (logger.isDebugEnabled()) {
					logger.debug("[createNewSoapMessageWithMTOMAttachment] - Using data Uncompressed");
				}
				barray = data.getBytes();
			}

			/*
			 * Use the Secure Hash Algorithm to create a hash that signs the
			 * data. The reason we need this is SST cannot validate the data
			 * when it is in an attachment. Therfore we are digitally signing
			 * the data ourselves and verifying it on the inbound side of the
			 * transaction.
			 */
			String digestValue = getSecureHash(barray);

			SOAPFactory soapFactory = SOAPFactory.newInstance();

			String svc = serviceHelper.getService();

			headers.addHeader(CONNECTION, CLOSE);
			headers.addHeader(SOAP_ACTION, serviceHelper.getSoapAction());
			headers.addHeader(Constants.CONTENT_TYPE, Constants.XOP_CONTENT_TYPE);

			String bodyStr = Constants.SOAP_MTOM_HEADER + Constants.SOAP_FOOTER;
			ByteArrayInputStream inputStream = new ByteArrayInputStream(bodyStr.getBytes());

			msg = getMessageFactory().createMessage(headers, inputStream);

			SOAPBody body = msg.getSOAPBody();

			Name payload = soapFactory.createName(serviceHelper.getResponseElementName(), MTOM_PAYLOAD,
					serviceHelper.getResponseElementNamespace());

			SOAPBodyElement bodyElement = body.addBodyElement(payload);

			// add the attachmentdata
			Name attachmentData = soapFactory.createName(serviceHelper.getRequestPartName(), "attachmentData",
					serviceHelper.getResponseElementNamespace());
			SOAPElement attachmentDataSoapElement = bodyElement.addChildElement(attachmentData);

			// Name xopContentType =
			// soapFactory.createName(MTOM_LOCAL_NS_PREFIX);
			// bodyElement.addAttribute(xopContentType,
			// Constants.XOP_CONTENT_TYPE);

			Name xopNameSpace = soapFactory.createName(XOP_LOCAL_NAME, XOP_PREFIX, Constants.MTOM_INCLUDE_NAMESPACE);

			attachmentId = UUID.randomUUID().toString();

			Name href = soapFactory.createName(HREF);
			SOAPElement symbol = attachmentDataSoapElement.addChildElement(xopNameSpace);

			symbol.addAttribute(href, ATTACHMENT_CONTENT_ID + attachmentId);

			attachmentDataSoapElement.addChildElement(symbol);

			SOAPHeader header = msg.getSOAPPart().getEnvelope().addHeader();
			/*
			 * Create a soap header element to add these properties to.
			 */
			String nameSpace = System.getProperty(Constants.PROP_ATTACHMENT_HASH_NS,
					Constants.HTTP_WWW_CAISO_COM_MRTU_SOA_SCHEMAS_2005_09_ATTACHMENTHASH);
			Name name = soapFactory.createName(Constants.ATTACHMENT_HASH, Constants.NS1, nameSpace);
			SOAPHeaderElement attachment_Hash_Element = header.addHeaderElement(name);

			/*
			 * Set the actor for this element
			 */
			attachment_Hash_Element.setActor(Constants.HTTP_SCHEMAS_XMLSOAP_ORG_SOAP_ACTOR_NEXT);
			attachment_Hash_Element.setMustUnderstand(false);

			/*
			 * Set the hash value into the header element
			 */
			SOAPElement hashValueElement = attachment_Hash_Element.addChildElement(Constants.HASH_VALUE, Constants.NS1);
			hashValueElement.addTextNode(digestValue);

			/*
			 * Create a name for the standard attachment information object.
			 */
			name = soapFactory.createName(Constants.STANDARD_ATTACHMENT_INFOR, Constants.NS1,
					Constants.STANDARD_ATTACHMENT_INFOR_NAMESPACE);

			/*
			 * Add another header element to hold the standard attachment
			 * information
			 */
			SOAPHeaderElement standard_Attachment_Element = header.addHeaderElement(name);
			attachment_Hash_Element.setActor(Constants.HTTP_SCHEMAS_XMLSOAP_ORG_SOAP_ACTOR_NEXT);

			/*
			 * If the mustUnderstand attribute is on, the actor who receives the
			 * SOAPHeaderElement must process it correctly. This ensures, for
			 * example, that if the SOAPHeaderElement object modifies the
			 * message, that the message is being modified correctly. Since
			 * there will be no modification of the message and the Large
			 * Message Implementation guideline tells us to set this to false we
			 * will do so.
			 */
			attachment_Hash_Element.setMustUnderstand(false);

			/*
			 * Create the attachment element and prepare it for the attachment.
			 */
			SOAPElement attachment_Element = standard_Attachment_Element.addChildElement(ATTACHMENT);
			SOAPElement id_Element = attachment_Element.addChildElement(Constants.ID);
			id_Element.addTextNode(Constants._1);

			/*
			 * Set a flag to show that the message attachment is compressed.
			 */
			SOAPElement flag_Element = attachment_Element.addChildElement(Constants.COMPRESS_FLAG);
			flag_Element.addTextNode(Constants.YES);

			/*
			 * Specify the compression method so that the end process knows how
			 * to decompress it.
			 */
			SOAPElement method_Element = attachment_Element.addChildElement(Constants.COMPRESS_METHOD);
			method_Element.addTextNode(Constants.GZIP);

			addMtomAttachmentToMessage(msg, barray, attachmentId);

		} catch (Exception e) {
			throw new SOAPException(e);
		}
		return msg;
	}

	public void addAttachmentToMessage(SOAPMessage msg, byte[] data) {
		/*
		 * Set the attachment into the new msg.
		 */
		ByteArrayInputStream bais = new ByteArrayInputStream(data);
		DataHandler dh = new DataHandler(new BinaryDataSource(bais));
		AttachmentPart attachment = msg.createAttachmentPart(dh);

		msg.addAttachmentPart(attachment);
	}

	/**
	 * Same as @see #addAttachmentToMessage(SOAPMessage, byte[]) with addition
	 * of ContentId.
	 * 
	 * @param msg
	 * @param data
	 * @param attachment_ContentId
	 */
	public void addMtomAttachmentToMessage(SOAPMessage msg, byte[] data, String attachment_ContentId) {
		/*
		 * Set the attachment into the new msg with content id.
		 */
		ByteArrayInputStream bais = new ByteArrayInputStream(data);
		DataHandler dh = new DataHandler(new BinaryDataSource(bais));
		AttachmentPart attachment = msg.createAttachmentPart(dh);
		attachment.setContentId(attachment_ContentId);

		msg.addAttachmentPart(attachment);
	}

	/**
	 * create an attachment Body string consisting of the RPC operation name
	 * (service) and the soap Action as the XMLNS, Also include the
	 * attachmentLocalName in the body as a tag. Even though this seems
	 * unnecessary other tools do it this way so we will too.
	 * 
	 * @return String representing the soap body of an attachment RPC style
	 *         message.
	 */
	public String getAttachmentBody() {

		String svc = serviceHelper.getService();
		String bodyStr = Constants.SOAP_HEADER + "<" + svc + " xmlns=\"" + serviceHelper.getSoapAction() + "\">" + "<"
				+ getAttachmentLocalName() + "/>" + "</" + svc + ">" + Constants.SOAP_FOOTER;
		return bodyStr;
	}

	/**
	 * Get the message Content from the message. We used to validate the content
	 * against the elementName expected for a request/response but this is
	 * really not necessary since validation has already occured in the
	 * integration layer. Therefore we are making the assumption here that if
	 * this is a request we are actually receiving the request.xsd and if this a
	 * response we are actually receiving the response.xsd as previously
	 * validated by the integration layer.
	 * 
	 * @param message
	 *            - the soap message to get the content from
	 * @return - An XML String representing the Content of the message. If there
	 *         is no content then null is returned.
	 * @throws SOAPException
	 *             - Bubbled up from the SAAJ Soap libraries. Also wraps any
	 *             exceptions from decompressing the data, Also is thrown if the
	 *             attachment hash is not valid.
	 */
	public String getSoapMessageContent(SOAPMessage message) throws SOAPException {
		return getSoapMessageContent(message, true);
	}

	/**
	 * Get the message Content from the message. We used to validate the content
	 * against the elementName expected for a request/response but this is
	 * really not necessary since validation has already occured in the
	 * integration layer. Therefore we are making the assumption here that if
	 * this is a request we are actually receiving the request.xsd and if this a
	 * response we are actually receiving the response.xsd as previously
	 * validated by the integration layer.
	 * 
	 * @param message
	 *            - the soap message to get the content from
	 * @param decompress
	 *            - decompress the return value if this is an attachment and
	 *            this param is true.
	 * @return - An XML String representing the Content of the message. If there
	 *         is no content then null is returned.
	 * @throws SOAPException
	 *             - Bubbled up from the SAAJ Soap libraries. Also wraps any
	 *             exceptions from decompressing the data, Also is thrown if the
	 *             attachment hash is not valid.
	 */
	public String getSoapMessageContent(SOAPMessage message, boolean decompress) throws SOAPException {
		if (message.getSOAPPart().getEnvelope().getBody().hasFault()) {
			return getFaultContent2(message);
		} else if ((mode == MODE_REQUEST && serviceHelper.isRequestWithAttachment())
				|| (mode == MODE_RESPONSE && serviceHelper.isResponseWithAttachment())) {
			return getContentFromAttachment(message, decompress);
		} else {
			return getContentFromSoapBody(message);
		}
	}

	/**
	 * Gets the content from the soap attachment. This method also verifies the
	 * hash that was sent into the message header at the start of this request.
	 * If the underlying data has been changed the hash will not match and a
	 * SOAPException will be thrown.
	 * 
	 * @param message
	 *            - the soap message to get the content from
	 * @param dexompress
	 *            - decompress the message content if true and attachment type.
	 * @return - A String representing the data for this message
	 * @throws SOAPException
	 *             - Underlying exceptions from decompressing the data are
	 *             bubbled up, also if the attachment hash does not validate
	 *             this exception is thrown.
	 */
	public String getContentFromAttachment(SOAPMessage message, boolean decompress) throws SOAPException {
		Iterator attachments = message.getAttachments();
		String result = null;
		try {
			/* Assume there is only one attachment */
			if (attachments.hasNext()) {
				AttachmentPart attachment = (AttachmentPart) attachments.next();
				if (logger.isDebugEnabled()) {
					logger.debug("[getContentFromAttachment] - attachment content: " + attachment.getContent());
				}
				InputStream content = (InputStream) attachment.getContent();
				String compressed = getStandardAttachmentInforValue(message, Constants.COMPRESS_FLAG);
				String compressedStream = new String(JAVAUtil.readBytes(content));

				/* Check the AttachmentHash against the attachment */
				String msgAttachmentHash = getAttachmentHashValue(message);
				if (msgAttachmentHash == null) {
					throw new SOAPException(
							"Attachment Hash header property does not exist in message, cannot continue!");
				}

				String attachmentHash = new String(getSecureHash(compressedStream.getBytes()));

				if (logger.isDebugEnabled()) {
					logger.debug("[getContentFromAttachment] - Generated attachmentHash: " + attachmentHash);
					logger.debug("[getContentFromAttachment] - MsgHeader attachmentHash: " + msgAttachmentHash);

				}
				if (!attachmentHash.equals(msgAttachmentHash)) {
					throw new SOAPException("Attachment Hash is not valid, cannot continue!");
				} else {
					if (logger.isDebugEnabled()) {
						logger.debug(
								"[getContentFromAttachment] - Attachment Hash Validated Successfully ! ! ! ! ! ! ! !");
					}
				}

				/*
				 * If the attachmentInformation value for the compression is no
				 * or the decompress param is null (indicating that even if the
				 * message is compressed don't decompress it then just return it
				 * as if it were plain text.
				 */
				if (logger.isDebugEnabled()) {
					logger.debug("[getContentFromAttachment] - Decompress Flag = " + decompress);
				}

				if ((compressed != null && compressed.equalsIgnoreCase("no")) || !decompress) {
					if (logger.isDebugEnabled()) {
						logger.debug(
								"[getContentFromAttachment] - Attachment is Plain Text or the decompress param is false");
					}
					result = compressedStream;
				} else {
					/*
					 * if it is compressed and decompress is true then
					 * decompress the content before returning the value.
					 */
					if (logger.isDebugEnabled()) {
						logger.debug("[getContentFromAttachment] - Attachment is compressed");
					}
					result = JAVAUtil.decompressBase64XML(compressedStream);
				}
			}
			if (logger.isDebugEnabled()) {
				logger.debug("[getContentFromAttachment] - Returning Attachment");
			}
			return result;
		} catch (NoSuchAlgorithmException e) {
			throw new SOAPException(e);
		} catch (IOException e) {
			throw new SOAPException(e);
		}

	}

	private String getFaultContent2(SOAPMessage message) throws SOAPException {
		TransformerFactory transFact = TransformerFactory.newInstance();
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		try {
			Source xsltSource = new StreamSource(new ByteArrayInputStream(Constants.SOAP_FAULT_XSLT.getBytes()));

			/* Create a new transformer based on the xslt */
			Transformer transformer = transFact.newTemplates(xsltSource).newTransformer();

			/* Create a stream result object for the transform call */
			StreamResult stream = new StreamResult(baos);

			/* Transform the XML removing all the soap identification tags */
			transformer.transform(message.getSOAPPart().getContent(), stream);

			String result = new String(baos.toByteArray());
			/*
			 * SST returns a xml haeder tag even if there are no details since
			 * we don't want to report this as an error set the result to null
			 * so that the calling code will report the faultString and code
			 * rather than the fault details.
			 */
			if (OutputDataTypeConstants.TAG_XML_HEADER.equals(result)) {
				result = null;
			}
			return result;
		} catch (TransformerConfigurationException e) {
			throw new SOAPException(e);
		} catch (TransformerException e) {
			throw new SOAPException(e);
		}

	}

	public boolean isRPCStyle() {
		return serviceHelper.getWSDLStyle().equalsIgnoreCase(Constants.STYLE_RPC);
	}

	private String getContentFromSoapBody(SOAPMessage message) throws SOAPException {
		return getContentFromSoapBody(message, false);
	}

	/**
	 * Gets the content from the soap body. Is called by
	 * <code>getSoapMessageContent()</code>. Can also be called to get the soap
	 * body from an incoming request message. This method does not look for a
	 * soap fault in the message. The above referenced method should be called
	 * if you need to check for soap faults.
	 * 
	 * @return - the data from this soap message
	 * @throws SOAPException
	 *             - SAAJ exceptions bubbled up here.
	 */
	private String getContentFromSoapBody(SOAPMessage message, boolean messageName) throws SOAPException {
		TransformerFactory transFact = TransformerFactory.newInstance();
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		/*
		 * If this is an RPC Style message and we got here then the body of the
		 * message will contain the payload we want but will be wrapped by the
		 * RPC Operation Name We therefore need to create an `XSLT that will
		 * strip this operation name as well as the soap envelope
		 * 
		 */
		String xslt = null;
		if (isRPCStyle()) {
			if (logger.isDebugEnabled()) {
				logger.debug("[getContentFromSoapBody] - RPC Style Message");
			}

			/*
			 * Get the operation Name, If messageName is true use the
			 * elementName otherwise use the serviceName
			 */
			String opName = (messageName) ? (mode == MODE_REQUEST ? serviceHelper.getService() + "Request"
					: serviceHelper.getService() + "Response") : serviceHelper.getService();

			xslt = Constants.SOAP_XSLT_NEW_BEGIN + Constants.SOAP_XSLT_NEW_BEGIN_RPC + opName
					+ Constants.SOAP_XSLT_NEW_END_RPC + Constants.SOAP_XSLT_NEW_END;
		} else {
			if (logger.isDebugEnabled()) {
				logger.debug("[getContentFromSoapBody] - Document Style Message");
			}
			xslt = Constants.SOAP_XSLT;
		}

		if (logger.isDebugEnabled()) {
			logger.debug("[getContentFromSoapBody] - xslt=" + xslt);
		}

		try {
			Source xsltSource = new StreamSource(new ByteArrayInputStream(xslt.getBytes()));

			/* Create a new transformer based on the xslt */
			Transformer transformer = transFact.newTemplates(xsltSource).newTransformer();

			/* Create a stream result object for the transform call */
			StreamResult stream = new StreamResult(baos);

			/* Transform the XML removing all the soap identification tags */
			transformer.transform(message.getSOAPPart().getContent(), stream);
			String result = new String(baos.toByteArray());
			/*
			 * If we have a null string then try the messageName instead of the
			 * operation Name by recursively calling this method.
			 */
			if (!messageName && isRPCStyle() && result.substring(result.length() - 2).equals("?>")) {
				result = getContentFromSoapBody(message, true);
			}

			/*
			 * if this is an RPC Style response and the partName is in the
			 * message as well as the eventLog tag then we need ot convert this.
			 */
			if (isRPCStyle() && (mode == MODE_RESPONSE) && result.indexOf("</" + getPartName() + ">") > 0
					&& result.indexOf("</" + EVENT_LOG + ">") > 0) {
				result = parseRPCStyleResponse(result, EVENT_LOG, getElementName());
			}
			return result;
		} catch (TransformerConfigurationException e) {
			throw new SOAPException(e);
		} catch (TransformerException e) {
			throw new SOAPException(e);
		}
	}

	public String getSoapContentFromSoapMessage(SOAPMessage message) throws SOAPException {
		ByteArrayOutputStream stream = new ByteArrayOutputStream();
		try {
			message.writeTo(stream);
		} catch (IOException e) {
			throw new SOAPException(e);
		}
		return new String(stream.toByteArray());
	}

	/**
	 * Create OutputDataType object for appropriate WSDL Style (RPC, Document)
	 * 
	 * @param eventResult
	 * @param eventName
	 * @param eventSeverity
	 * @param eventType
	 * @param eventDescription
	 * @param serviceName
	 * @param serviceDescription
	 * @param serviceComments
	 * @return XML that represents proper response.
	 * @throws SOAPException
	 * @throws SOAPException
	 * @throws XMLBindException
	 * @throws JAXBException
	 */
	public String createOutputDataType(String eventResult, String eventName, String eventSeverity, String eventType,
			String eventDescription, String serviceName, String serviceDescription, String serviceComments)
			throws SOAPException {
		String result = null;
		try {
			if (isRPCStyle()) {
				result = createRPCStyleResponse(eventResult, eventName, eventSeverity, eventType, eventDescription,
						serviceName, serviceDescription, serviceComments, getServiceName(), getSoapAction(),
						getPartName());

			} else {
				result = createOutputDataType(eventResult, eventName, eventSeverity, eventType, eventDescription,
						serviceName, serviceDescription, serviceComments);
			}
			return result;
		} catch (XMLBindException e) {
			throw new SOAPException(e.getMessage(), e);
		} catch (JAXBException e) {
			throw new SOAPException(e.getMessage(), e);
		}
	}

	/**
	 * Create a new SOAPMessage for a new soap request.
	 * <p>
	 * This method can only be called if the SoapMessageHelper is in Request
	 * Mode. This mode is determined based on the constructor called. The
	 * <code>SoapMessageHelper(SOAPMessage msg)</code> constructor puts the
	 * SoapMessageHelper in Response mode, all other constructors puts the
	 * SoapMessageHelper in Request Mode. The data will be compressed and uue.
	 * 
	 * @param data
	 *            - The data to bundle in the request.
	 * @return - A new SOAPMessage
	 * @throws SOAPException
	 *             - Bubbled up from the SAAJ API.
	 */
	public SOAPMessage createSoapMessage(String data) throws SOAPException {
		return createSoapMessage(data, true);
	}

	/**
	 * Create a new SOAPMessage for a new soap request.
	 * <p>
	 * This method can only be called if the SoapMessageHelper is in Request
	 * Mode. This mode is determined based on the constructor called. The
	 * <code>SoapMessageHelper(SOAPMessage msg)</code> constructor puts the
	 * SoapMessageHelper in Response mode, all other constructors puts the
	 * SoapMessageHelper in Request Mode. based on the compressed param the data
	 * will be compressed and uue if true.
	 * 
	 * @param data
	 *            - The data to bundle in the request.
	 * @param compressed
	 *            - the data will be compressed and uue if true
	 * @return - A new SOAPMessage
	 * @throws SOAPException
	 *             - Bubbled up from the SAAJ API.
	 */
	public SOAPMessage createSoapMessage(String data, boolean compressed) throws SOAPException {
		boolean attachment = false;
		if (logger.isDebugEnabled()) {
			logger.debug("[createSoapMessage] - Started");
		}
		switch (mode) {
		case MODE_REQUEST:
			attachment = serviceHelper.isRequestWithAttachment();
			break;
		case MODE_RESPONSE:
			attachment = serviceHelper.isResponseWithAttachment();
			break;
		default:
			throw new SOAPException("Cannot Create Soap Message Invalid Mode: " + mode);
		}
		if (attachment) {
			if (serviceHelper.isRequestMtom() || serviceHelper.isResponseMtom()) {
				logger.debug("[createMtomSoapMessage] - Creating Mtom Soap Message (WITH ATTACHMENT)");
				return createNewSoapMessageWithMTOMAttachment(data, compressed);
			} else {
				logger.debug("[createSoapMessage] - Creating Soap Message (WITH ATTACHMENT)");
				return createNewSoapMessageWithAttachment(data, compressed);
			}
		} else {
			if (logger.isDebugEnabled()) {
				logger.debug("[createSoapMessage] - Creating Soap Message (NO ATTACHMENT)");
			}
			return createNewSoapMessage(data);
		}
	}

	/**
	 * Creates SOAP Fault with short and long descriptions for code and string.
	 * This is a static method so that it can be called without even the
	 * serviceHelper or one of the subclasses RequestMessageHelper,
	 * ResponseMessageHelper needing to be created.
	 *
	 * @param faultCode
	 *            - Fault Code Short Description for the fault e.g. Server or
	 *            Client
	 * @param faultString
	 *            - Long Description for the fault
	 *
	 * @return pFaultString Error Message
	 */
	public static SOAPMessage createSOAPFaultMessage(String faultCode, String faultString) throws SOAPException {
		if (logger.isDebugEnabled()) {
			logger.debug("[createSOAPFaultMessage] - Started");
		}
		SOAPMessage msg = MessageFactory.newInstance().createMessage();

		if (logger.isDebugEnabled()) {
			logger.debug("[createSOAPFaultMessage] - Setting up QName for FaultCode");
		}

		if (logger.isDebugEnabled()) {
			logger.debug("[createSOAPFaultMessage] - Setting Fault Code and Fault String");
		}
		SOAPFault fault = msg.getSOAPPart().getEnvelope().getBody().addFault();
		fault.setFaultCode(Constants.NS1 + ":" + faultCode);
		fault.setFaultString(faultString);

		return msg;
	}

	public static SOAPMessage createSOAPFaultMessageWithNamespace(String faultCode, String faultString,
			String namespaceURI) throws SOAPException {

		SOAPMessage msg = MessageFactory.newInstance().createMessage();
		SOAPEnvelope env = msg.getSOAPPart().getEnvelope();
		Name qname = env.createName(Constants.SOAP_FAULT_CODE_SERVER, null, namespaceURI);

		if (logger.isDebugEnabled()) {
			logger.debug("[createSOAPFaultMessage] - Setting up QName for FaultCode");
		}

		if (logger.isDebugEnabled()) {
			logger.debug("[createSOAPFaultMessage] - Setting Fault Code and Fault String");
		}
		SOAPFault fault = msg.getSOAPPart().getEnvelope().getBody().addFault();
		fault.setFaultCode(qname);
		fault.setFaultString(faultString);

		return msg;
	}

	/**
	 * Creates SOAP Fault with standard Server Fault Code and Generic Fault
	 * String.
	 * 
	 * @param standardOutputData
	 *            - A standard Output XML String to use as the details
	 * @return - Soap Message with Fault
	 */
	public SOAPMessage createSOAPFaultMessage(String standardOutputData) throws SOAPException {
		return createSOAPFaultMessage(standardOutputData, Constants.SOAP_FAULT_CODE_SERVER,
				SOAP_FAULT_STRING_EXCEPTION_OCCURED);
	}

	/**
	 * Creates SOAP Fault with standard Server Fault Code and Generic Fault
	 * String.
	 * 
	 * @param outputData
	 *            - An outputDataTypeException to use as the details
	 * @return - Soap Message with Fault
	 */
	public SOAPMessage createSOAPFaultMessage(OutputDataTypeException outputData) throws SOAPException {
		String data = null;
		try {
			if (logger.isDebugEnabled()) {
				logger.debug("[createSOAPFaultMessage] - Parsing OutputDataTypeException");
			}

			if (!outputData.isXML()) {
				XMLBindUtility bindUtility;
				bindUtility = new XMLBindUtility(serviceHelper.getJAXBContextPath());
				data = bindUtility.marshal(outputData.getOutputData());
			} else {
				data = (String) outputData.getOutputData();
			}
		} catch (XMLBindException e) {
			throw new SOAPException(e);
		}
		if (logger.isDebugEnabled()) {
			logger.debug("[createSOAPFaultMessage] - Calling createSoapFaultMessage(String, String, String)");
		}
		return createSOAPFaultMessage(data, Constants.SOAP_FAULT_CODE_SERVER, SOAP_FAULT_STRING_EXCEPTION_OCCURED);
		
	}

	/**
	 * Creates SOAP Fault with standardOutputData as the details
	 *
	 * 
	 * @param standardOutputData
	 *            - a Standard Output XML String to use as the details
	 * @param faultCode
	 *            - Fault Code Short Description for the fault e.g. Server or
	 *            Client
	 * @param faultString
	 *            - Long Description for the fault
	 * 
	 * @return Soap Message with Fault
	 */
	public SOAPMessage createSOAPFaultMessage(String standardOutputData, String faultCode, String faultString)
			throws SOAPException {
		
		if (logger.isDebugEnabled()) {
			logger.debug("[createSOAPFaultMessage] - Started");
		}
		MessageFactory mf = MessageFactory.newInstance();
		SOAPMessage soapFaultMessage = mf.createMessage();
		SOAPFault fault = soapFaultMessage.getSOAPBody().addFault();
		fault.setFaultCode(faultCode);
		fault.setFaultString(faultString);
		
		String msg = standardOutputData.substring(standardOutputData.indexOf("?>") + 2);
		StringBuffer buf = new StringBuffer();
		// Add SOAP ENV header and footer. This seems too easy an may need
		// a parser
		buf.append(FAULT_HEADER);
		buf.append(FAULT_CODE_HEADER);
		buf.append(FAULT_NAMESPACE + ":" + faultCode);
		buf.append(FAULT_CODE_FOOTER);
		buf.append(FAULT_STRING_HEADER);
		buf.append(faultString);
		buf.append(FAULT_STRING_FOOTER);
		buf.append(FAULT_DETAIL_HEADER);
		buf.append(msg);
		buf.append(FAULT_DETAIL_FOOTER);
		buf.append(FAULT_FOOTER);

		if (logger.isDebugEnabled()) {
			logger.debug("\n\n\nformatted parsed: " + buf.toString());
		}
		// Convert XML response into SOAPMessage
		DOMSource domSource;
		DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder;

		try {
			SOAPMessage message = getMessageFactory().createMessage();
			builder = docFactory.newDocumentBuilder();

			Document document = builder.parse(new ByteArrayInputStream(buf.toString().getBytes()));
			domSource = new DOMSource(document);

			// Get the SOAP part and set its content to domSource
			SOAPPart soapPart = message.getSOAPPart();
			soapPart.setContent(domSource);
			return message;
		} catch (ParserConfigurationException e) {
			throw new SOAPException(e);
		} catch (SAXException e) {
			throw new SOAPException(e);
		} catch (IOException e) {
			throw new SOAPException(e);
		}
	}

	/**
	 * if the message has a soap fault then return true. Also return the fault
	 * code and fault string in the respective parameters.
	 * 
	 * @param message
	 *            - The message to check for a fault
	 * @param faultCode
	 *            - Return the fault Code if there is one
	 * @param faultString
	 *            - Return the faultString if there is one.
	 * @return - True if there is a fault else false.
	 * @throws SOAPException
	 */
	public boolean hasSoapFault(SOAPMessage message) throws SOAPException {
		SOAPBody body = message.getSOAPPart().getEnvelope().getBody();
		return body.hasFault();
	}

	public String getSoapFaultDescription(SOAPMessage message) throws SOAPException {
		String result = null;
		SOAPBody body = message.getSOAPPart().getEnvelope().getBody();
		if (body.hasFault()) {
			result = body.getFault().getFaultCode() + " - " + body.getFault().getFaultString();
		} else {
			result = "No Fault exists for this message";
		}
		return result;

	}

	/**
	 * Check the message size against the max size if this message is not a
	 * large message WSDL
	 * 
	 * @param message
	 * @return
	 */
	public boolean isMessageToBig(String message) {
		// check to see if message is too big
		boolean withAtt = (mode == MODE_REQUEST) ? serviceHelper.isRequestWithAttachment()
				: serviceHelper.isResponseWithAttachment();
		int maxSize = serviceHelper.getMaxAttachmentSize();

		if ((!withAtt) && (message.length() > maxSize)) {
			logger.debug(
					"[isMessageToBig(String)] - Message size " + message.length() + " exceeds limit of " + maxSize);
			return true;
		} else {
			if (logger.isDebugEnabled()) {
				logger.debug("[isMessageToBig] - Message is OK Size: " + message.length());
			}
			return false;
		}
	}

	public static String parseRPCStyleResponse(String response, String firstInnerTag, String elementName)
			throws SOAPException {

		String data;

		try {
			data = deconstructRPCStyleResponse(response, firstInnerTag, elementName);
		} catch (ParserConfigurationException e) {
			throw new SOAPException(e.getMessage(), e);
		} catch (SAXException e) {
			throw new SOAPException(e.getMessage(), e);
		} catch (IOException e) {
			throw new SOAPException(e.getMessage(), e);
		} catch (TransformerException e) {
			throw new SOAPException(e.getMessage(), e);
		}
		return data;
	}

	private static String deconstructRPCStyleResponse(String data, String firstInnerTag, String elementName)
			throws ParserConfigurationException, SAXException, IOException, TransformerException, SOAPException {
		Document document = xmlToDom(data);

		/*
		 * We are assuming that the first child node is the partName node then
		 * the next child will be the eventLogNode
		 */
		Node partNameNode = document.getFirstChild();
		Node eventLogNode = null;
		NodeList eventLogNodes = partNameNode.getChildNodes();
		for (int i = 0; i < eventLogNodes.getLength(); i++) {
			if (eventLogNodes.item(i).getNodeName().equalsIgnoreCase(firstInnerTag)) {
				eventLogNode = eventLogNodes.item(i);
				break;
			}
		}

		if (eventLogNode == null) {
			throw new SOAPException("Response data does not contain " + firstInnerTag + " node");
		}

		/* Get the value for the XMLNS attribute to add to the outputData tag */
		Node nsNode = eventLogNode.getAttributes().getNamedItem(XMLNS);

		String nsValue = null;
		if (nsNode != null) {
			nsValue = nsNode.getNodeValue();
		} else {
			throw new SOAPException("Namespace attribute " + XMLNS + " Does not exist in first child node");
		}

		/*
		 * Remove the eventlogNode name space attribute and add it to the new
		 * outer node.
		 */
		eventLogNode.getAttributes().removeNamedItem(XMLNS);

		/*
		 * Create a new node for the namespace attribute to add to the element
		 * name node
		 */
		Node nameSpaceNode = document.createAttribute(XMLNS);
		nameSpaceNode.setNodeValue(nsValue);

		Node elementNameNode = document.createElement(elementName);

		/*
		 * Set the outputData namespace as an attribute of the elementNameNode
		 * tag
		 */
		elementNameNode.getAttributes().setNamedItem(nameSpaceNode);

		/* Add the eventLog tag back to the elementNameNode as a child */
		elementNameNode.appendChild(eventLogNode);

		/* Replace the partName with the elementNameNode */
		document.replaceChild(elementNameNode, partNameNode);

		/* Convert the dom document back to XML before returning */
		return domToXML(document);
	}

	/**
	 * Create an rpcStyle Response from the xml string in Data with the outer
	 * tag equal to the operation name with namespace and the next tag equal to
	 * the partName parameter
	 * 
	 * @param data
	 *            - XML String representing OutputDataType as formatted by JAXB
	 * @param operationName
	 *            - the operationName to use as the outer tag
	 * @param nameSpace
	 *            - the nameSpace for the operationName tag
	 * @param partName
	 *            - the partName tag
	 * @return - a DOM Document that contains the structure as described above.
	 * @throws ParserConfigurationException
	 *             - if the parser cannot be setup properly I guess??
	 * @throws SAXException
	 *             - throw by xmlToDom if the XML is unparsable
	 * @throws IOException
	 *             - thrown by xmlToDom if there is a problem reading the input
	 *             stream
	 * @throws TransformerException
	 *             if the resulting DOM document fails to transform back to XML
	 * @throws SOAPException
	 */
	private static String constructRPCStyleResponse(String data, String operationName, String nameSpace,
			String partName)
			throws ParserConfigurationException, SAXException, IOException, TransformerException, SOAPException {

		/*
		 * Create a DOM document object. This document will initially contain
		 * the outputDAtaType object that was created using the JAXB object
		 * model
		 * 
		 * Because RCP requires a format different from the actual XSD we will
		 * reformat the output appropriately. 1. Get the NameSpace from the
		 * outputDataType tag by accessing the associated attribute 2. Create an
		 * attribute node for the NameSpace 3. Get the first child of the
		 * outputDataType which should be the EventLog tag. 4. Add the namespace
		 * attribute node to this tag 5. Replace the outputDataType child in the
		 * DOM Document with the new EventLog Node. The resulting output will
		 * now look like this. Notice the outputDataType tag has been removed.
		 * <EventLog
		 * xmlns="http://www.caiso.com/soa/20060613/OutputDataType.xsd"> ... the
		 * rest of the body ... </EventLog>
		 */

		/* Create a DOM document structure form the inbound XML */
		Document document = xmlToDom(data);

		/* The first child node should be the outputDataNode */
		Node outputDataNode = document.getFirstChild();

		/* Get the value for the XMLNS attribute to add to the event log tag */
		Node nsNode = outputDataNode.getAttributes().getNamedItem(XMLNS);

		String nsValue = null;
		if (nsNode != null) {
			nsValue = nsNode.getNodeValue();
		} else {
			throw new SOAPException("Namespace attribute " + XMLNS + " Does not exist in first child node");
		}

		/*
		 * Create a new node for the namespace attribute to add to the event log
		 * node
		 */
		Node nameSpaceNode = document.createAttribute(XMLNS);
		nameSpaceNode.setNodeValue(nsValue);

		/* Should get the eventLog Node from the first child. */
		Node eventLogNode = outputDataNode.getFirstChild();

		/* Set the outputData namespace as an attribute of the event log tag */
		eventLogNode.getAttributes().setNamedItem(nameSpaceNode);

		/*
		 * Now build the tree with operation name and namespace as the first
		 * child,
		 */
		Node partNameNode = document.createElement(partName);
		partNameNode.appendChild(eventLogNode);

		/*
		 * If the operationName does not contain a prefix then we need to add
		 * one if the operationName contains a colon then it is prefixed else we
		 * will add the generic NS1 prefix
		 */
		if (operationName.indexOf(':') == -1) {
			operationName = Constants.NS1 + ":" + operationName;
		}
		Node operationNameNode = document.createElementNS(nameSpace, operationName + Constants.RESPONSE_SUFFIX);
		operationNameNode.appendChild(partNameNode);

		/* Replace the outputDataNode with the eventLogNode */
		document.replaceChild(operationNameNode, outputDataNode);

		/* Convert the dom document back to XML before returning */
		return domToXML(document);
	}

	private static Document xmlToDom(String xml) throws ParserConfigurationException, SAXException, IOException {
		DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = docFactory.newDocumentBuilder();
		Document document = builder.parse(new ByteArrayInputStream(xml.getBytes()));
		return document;
	}

	private static String domToXML(Document domDocument) throws TransformerException {
		/* Use JAXP to parse the DOM structure into XML */
		DOMSource source = new DOMSource(domDocument);
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		StreamResult result = new StreamResult(baos);
		TransformerFactory tf = TransformerFactory.newInstance();
		Transformer serializer = tf.newTransformer();
		serializer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
		serializer.setOutputProperty(OutputKeys.INDENT, "yes");
		serializer.transform(source, result);
		return baos.toString();
	}

	public String createRPCStyleResponse(String eventResult, String eventName, String eventSeverity, String eventType,
			String eventDescription, String serviceName, String serviceDescription, String serviceComments,
			String operationName, String nameSpace, String partName)
			throws XMLBindException, JAXBException, SOAPException {

		String data;

		data = createOutputDataType(eventResult, eventName, eventSeverity, eventType, eventDescription, serviceName,
				serviceDescription, serviceComments);

		try {
			data = constructRPCStyleResponse(data, operationName, nameSpace, partName);
		} catch (ParserConfigurationException e) {
			throw new SOAPException(e.getMessage(), e);
		} catch (SAXException e) {
			throw new SOAPException(e.getMessage(), e);
		} catch (IOException e) {
			throw new SOAPException(e.getMessage(), e);
		} catch (TransformerException e) {
			throw new SOAPException(e.getMessage(), e);
		}
		return data;
	}

	public String getPayload() throws SOAPException {
		String retVal = getContentFromAttachment(soapMessage, true);
		if (retVal == null || retVal.length() == 0) {
			throw new SOAPException("Request payload does not exist in message for service: " + serviceHelper.getService()
					+ " Expected ElementName: " + serviceHelper.getRequestElementName());
		}
		return retVal;
	}

}
