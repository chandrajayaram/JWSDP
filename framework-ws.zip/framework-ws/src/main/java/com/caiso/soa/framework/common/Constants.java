/**
 * $Header: //depot/Perforce Depot/Market Systems/Applications/Integration-WS/Framework/src/java/com/caiso/soa/framework/common/Constants.java#4 $
 * $Revision: #4 $
 * $Date: 2012/03/06 $
 * $Author: iloh $
 */
package com.caiso.soa.framework.common;

import com.caiso.soa.common.constants.BroadcastConstants;


/**
 * All constants files are located in the caiso-commons-utils project in the package
 * <code>com.caiso.soa.common.constants</code>
 * They have been broken into files related to the constants usage. The groupings
 * are as follows:
 * 
 * <ul>
 * <li>StandardConstants - Standard constant values, such as YES, NO, TRUE, FALSE etc.</li>
 * <li>PropertyFileConstants - Constants related to creating property files.</li>
 * <li>ConnectorConstants - Constants related to creating a connector adapter.</li>
 * <li>AttachmentConstants - Constants related to creating an attachment for large message delivery.</li>
 * <li>BroadcastConstants - Constants related to the broadcast features of the framework.</li>
 * </ul>
 * 
 * <p>Each file derives from the previous one so that all files contain the necessary
 * constants. Finally this file (framework.Constants) derives from the last 
 * file in the above list, BroadcastConstants, and is therefore, a reflection of 
 * all the constants. While this may not be the most readable way to handle 
 * refactoring constants into groups, this does allow for minimal change to the 
 * framework during this refactoring process.
 *
 * @author mpope, tflora
 */
public interface Constants extends BroadcastConstants {
	public static final String RETRY_COUNT = ".retrycount";
	public static final String RETRY_INTERVAL = ".retryinterval";
	public static final String RETRY_COUNT_DEF = "3";
	public static final String RETRY_INTERVAL_DEF = "1000";
	public static final String EXCEPTION_SERVICE_NAME = "CAISO:name=OutputDataException-Service";
	public static final String EXCEPTION_SERVICE_METHOD = "handleException";
	public static final String[] EXCEPTION_SERVICE_SIGNATURE = new String[]{String.class.getName(), Throwable.class.getName()};
	public static final String COMMON_EVENT_URL_DEF = "http://www.caiso.com/soa/2005-05-24/commonHandleManagedEvent";
	public static final String SERVLET_HANDLER_URL_DEF = "http://localhost:8080/servlet/MessageHandler";
	public static final String COMMON_EVENT_URL_NAME = "http://www.caiso.com/soa/2005-05-24/commonHandleManagedEvent";
	public static final String SERVLET_HANDLER_URL_NAME = "http://localhost:8080/servlet/MessageHandler";
	
	/**
	 * Caiso User Token fields for looking up token values from soap header.
	 */
	public static final String CAISO_WS_HEADER_NAME = "CAISOWSHeader";
	public static final String CAISO_WS_USER_TOKEN_NAME = "CAISOUsernameToken";
	public static final String CAISO_WS_PREFIX = "cwsh";
	public static final String CAISO_WS_NAMESPACE = "http://www.caiso.com/soa/2006-09-30/CAISOWSHeader.xsd";
	public static final String CAISO_WS_USER_NAME = "Username";
	public static final String CAISO_WS_NONCE = "Nonce";
	public static final String CAISO_WS_CREATED = "Created";
	
	public static final String ATTACHMENT_HASH_NAME = "attachmentHash";
	public static final String ATTACHMENT_HASH_PREFIX = "ns1";
	
	
	public static final String PRINT_PAYLOAD = "framework.printpayload";
	public static final String SOAP_ENVELOPE = "SOAPEnvelope";
	public static final String STANDARD_ATTACHMENT_INFOR_NAMESPACE = "http://www.caiso.com/soa/2006-06-13/StandardAttachmentInfor.xsd";
	
	public static final String XML_VERSION = "<?xml version=\"1.0\" encoding=\"UTF-8\"?> " ;
	public static final String SOAP_XSLT_NEW_BEGIN = XML_VERSION + "<xsl:stylesheet version=\"1.0\" xmlns:xsl=\"http://www.w3.org/1999/XSL/Transform\" xmlns:fo=\"http://www.w3.org/1999/XSL/Format\">" +
	"<xsl:output method=\"xml\"/>" +
	"<xsl:template match=\"/\">" + 
	"<xsl:copy-of select=\"/*[local-name()='Envelope']/*[local-name()='Body']/*"; 
	public static final String SOAP_XSLT_NEW_BEGIN_RPC = "[local-name()='";
	public static final String SOAP_XSLT_NEW_END_RPC = "']/*\"/>"; 
	public static final String SOAP_XSLT_NEW_END = "</xsl:template>" + "</xsl:stylesheet>";	
	public static final String RESPONSE_SUFFIX = "Response";
	public static final String PROP_CAISO_WSHEADER_NS = "framework.caisowsheaderns";
	public static final String PROP_ATTACHMENT_HASH_NS = "framework.attachmenthashns";
	public static final String PROP_STANDARD_ATTACHMENT_NS = "framework.standardattachmentns";
	public static final String PROP_DEFAULT_FILE_ENCODING = "default.file.encoding";
	
	public static final String DEFAULT_SOA_PUBLISHER_BEAN_NAME = "defaultSoaPublisher";
	// Copied from @see com.caiso.esb.common.Constants.HEADER_UUID
	public static final String HEADER_UUID = "MessageUUID";
}
