/*
 * Copyright (c) 2005 California ISO. All rights reserved.
 */
package com.caiso.soa.framework.common.exception;


/**
 * Base exception class for all com.caiso.soa.ehs related exceptions.
 * 
 * @author <a href="mailto:mpope@caiso.com?Subject=JAVADOC - Question about com.caiso.soa.ehs.common.Messages.java"> Mark Pope</a>
 * @version $Revision:  $ $Date:  $
 *
 * @Copyright (c) California ISO 2005
 *
 */

public class BaseException
extends Exception {
	
	private static final long serialVersionUID = -9158368789363893334L;
    /**
     * Creates a new BaseException object.
     */
    public BaseException() {
        super();
        
    }

    /**
     * Creates a new BaseException object.
     *
     * @param pString exception message
     */
    public BaseException(String pString) {
        super(pString);
    }

    /**
     * Creates a new BaseException object.
     *
     * @param pString exception message
     * @param pThrowable root exception
     */
    public BaseException(String pString, Throwable pThrowable) {
        super(pString, pThrowable);
    }

    /**
     * Creates a new BaseException object.
     *
     * @param pException root exception
     */
    public BaseException(Exception pException) {
        super(pException);
    }
    /**
     * Creates a new BaseException object.
     *
     * @param pException root exception
     */
    public BaseException(Throwable pThrowable) {
        super(pThrowable);
    }
}
