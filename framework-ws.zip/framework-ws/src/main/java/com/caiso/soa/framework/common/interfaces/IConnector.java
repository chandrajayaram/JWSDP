package com.caiso.soa.framework.common.interfaces;

/**
 * Base interface for connectors.
 * 
 * @author tflora
 *
 */
public interface IConnector {

	/**
	 * @return Data type. XML String or JAXB object(pojo).
	 */
	public String getDataType();

	/**
	 * Implement getter/setter
	 *
	 * @param pDataType
	 */
	public void setDataType(String pDataType);

}
