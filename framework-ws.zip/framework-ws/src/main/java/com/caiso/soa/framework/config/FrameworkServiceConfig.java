package com.caiso.soa.framework.config;

import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@ComponentScan({"com.caiso.soa.framework.ws"})
@ServletComponentScan({"com.caiso.soa.framework.ws"})
@Configuration
public class FrameworkServiceConfig
{
  public FrameworkServiceConfig() {}
}

