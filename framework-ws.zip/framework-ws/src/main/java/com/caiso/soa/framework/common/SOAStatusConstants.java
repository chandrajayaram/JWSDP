/*
 * Copyright (c) 2004 California ISO. All rights reserved.
 */
package com.caiso.soa.framework.common;

/**
 * Return Status codes of StandardOutput. 
 *
 * @author $author$
 * @version $Revision$
 */
public interface SOAStatusConstants {
	
	/*
	 * Found in MRTU Integration Guide.
	 */
	public final static String RECEIVE_SERVICE_SUCCESS       = "SCSS0001";
	public final static String BROADCAST_SERVICE_INT_FAILURE = "JMS0001";
	public final static String BROADCAST_SERVICE_EXT_FAILURE = "JMS0002";
	
	/*
	 * Framework status codes
	 */
	public static final String FRAMEWORK_PREFIX = "FMWK";
	public final static String PERSISTENCE_CONNECTOR_FAILURE = FRAMEWORK_PREFIX + "0001";
	public final static String MESSAGE_SERVICE_FAILURE       = FRAMEWORK_PREFIX + "0002";
	public final static String MESSAGE_EJB_FAILURE           = FRAMEWORK_PREFIX + "0003";

	public final static String BROADCAST_CONNECTOR_FAILURE   = FRAMEWORK_PREFIX + "0004";
	public final static String SCHEDULER_FAILURE             = FRAMEWORK_PREFIX + "0005";
	public final static String CONNECTOR_FAILURE			 = FRAMEWORK_PREFIX + "0006";
	public final static String BROADCAST_SCHEDULER_FAILURE 	 = FRAMEWORK_PREFIX + "0007";
	
	public final static String RETRIEVE_CONNECTOR_FAILURE    = FRAMEWORK_PREFIX + "0008";
	public final static String RECEIVE_CONNECTOR_FAILURE     = FRAMEWORK_PREFIX + "0009";
	public final static String RECEIVE_CONNECTOR_NOT_SPECIFIED = FRAMEWORK_PREFIX + "0010";
	
	
	public static final String NAME_FRAMEWORK = "Caiso-SOA-Framework";
	
	public static final String SEVERITY_ERROR = "ERROR";
	public static final String SEVERITY_FATAL = "FATAL";
	public static final String SEVERITY_INFO = "INFO";
	public static final String SEVERITY_WARN = "WARN";
	
	public static final String NO_CONNECTOR_SPECIFIED = "No connector specified for this service. Add a property <service name>.connector=com.your.class to conf/your.properties.";
	
	public static final String RESPONSE_TOO_BIG = "Response exceeds maximum allowed size. Use Large Message Service";
	public static final String REQUEST_TOO_BIG = "Request exceeds maximum allowed size. Use Large Message Service";
	
	public static final String INVALID_CONNECTOR_INTERFACE = "Invalid Connector Interface"; 
	public static final String INVALID_CONNECTOR_MSG = "Connector must be an instance of IConnectorAdapter or IExtConnectorAdapter";
}
