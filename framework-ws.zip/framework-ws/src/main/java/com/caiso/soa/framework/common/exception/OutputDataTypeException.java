package com.caiso.soa.framework.common.exception;

/*
 *  This exception is a wrapper for passing back SOAPFault data as a JAXB 
 * object or XML string. It is not aware of the data to support WSDL versioning.
 *
 * @author <a href="mailto:mpope@caiso.com?Subject=JAVADOC - Question about com.caiso.soa.framework.common.exception.OutputDataTypeException.java"> Mark Pope</a>
 * @version $Revision:  $ $Date:  $
 *
 * @Copyright (c) California ISO 2005
 *
 */
public class OutputDataTypeException extends BaseException {

    /**
	 * For serialization
	 */
	private static final long serialVersionUID = 2470542402642597720L;
	private Object data = null;
       
    /**
     *  Default constructor
     *
     */
    public OutputDataTypeException() {

    }
    
    /**
     *  Allows creator to pass back event described XML data. Must adhere
     *  to StandardOutput.xsd for specific version of web services.
     */
    public OutputDataTypeException(String pXmlData) {
        data = pXmlData;
    
    }
    
    /**
     * Allows creator to pass back error as JAXB object. Must adhere
     * to StandardOutput.xsd for specific version of web services.
     * Class must be 
     * 			OutputDataTypeType from 
     * 					com.caiso.soa.common.data.jaxb.<version>.<service>
     * 
     * @param pObject @see com.sun.xml.bind.JAXBObject a populated instance of OutputDataTypeType
     */
    public OutputDataTypeException(Object pObject){
        data = pObject;
    }
  
    
    /**
     * Is ouputdata stored as an XML String or JAXB Object. 
     * @return true if data is XML String.
     */
    public boolean isXML() {
        return data instanceof java.lang.String;
    }
   
    /**
     * Provides output data passed in constructor.
     * @return
     */
    
    public Object getOutputData() {
            return data;
    }
}
