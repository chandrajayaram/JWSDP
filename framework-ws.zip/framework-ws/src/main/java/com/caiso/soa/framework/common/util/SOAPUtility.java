/*
 * Copyright (c) 2005 California ISO. All rights reserved.
 */
package com.caiso.soa.framework.common.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.TimeZone;

import javax.xml.bind.JAXBException;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.soap.Detail;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.Name;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPFault;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Source;
import javax.xml.transform.Templates;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.caiso.soa._2006_06_13.Event;
import com.caiso.soa._2006_06_13.EventLog;
import com.caiso.soa._2006_06_13.ObjectFactory;
import com.caiso.soa._2006_06_13.OutputDataType;
import com.caiso.soa._2006_06_13.Service;
import com.caiso.soa.common.util.SOASysUtility;
import com.caiso.soa.common.util.UUIDGenerator;
import com.caiso.soa.framework.common.Constants;
import com.caiso.soa.framework.common.OutputDataTypeConstants;
import com.caiso.soa.framework.common.SOAStatusConstants;
import com.caiso.soa.framework.common.exception.OutputDataTypeException;
import com.caiso.soa.framework.common.exception.XMLBindException;


/*
 * Convienence utility for creating SOAP messages
 *
 * @author <a href="mailto:mpope@caiso.com?Subject=JAVADOC - Question about
 * com.caiso.soa.framework.common.util.SOAPUtil.java"> Mark Pope </a>
 *
 * @version $Revision: $ $Date: $
 *
 * @Copyright (c) California ISO 2005
 *
 */
public class SOAPUtility {
    private static Logger logger = Logger.getLogger(SOAPUtility.class);
    private static Templates cachedXSLT = null;
    private static Templates cachedFaultXSLT = null;
    private static String XMLNS = "xmlns";

    static {
        Source xsltSource =
            new StreamSource(
                new ByteArrayInputStream(Constants.SOAP_XSLT.getBytes()));
        TransformerFactory transFact = TransformerFactory.newInstance();
        Source xsltFaultSource = new StreamSource(
        		new ByteArrayInputStream(Constants.SOAP_FAULT_XSLT.getBytes()));
        try {
            cachedXSLT = transFact.newTemplates(xsltSource);
            cachedFaultXSLT = transFact.newTemplates(xsltFaultSource);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Creates SOAP Fault
     *
     * @param pService Fault String
     * @param pFaultCode Fault Code e.g. Server or Client
     * @param pFaultString DOCUMENT ME!
     *
     * @return pFaultString Error Message
     */
    public static SOAPMessage createSOAPFaultMessage(
        SOAPMessage pOutMessage,
    	String pService,
        String pFaultCode,
        String pFaultString)
        throws SOAPException {
        SOAPBody body = pOutMessage.getSOAPPart().getEnvelope().getBody();
        SOAPFault fault = body.addFault();
        fault.setFaultCode(pFaultCode);
        fault.setFaultString(pFaultString);

        return pOutMessage;
    }
    
    /**
     * Creates a soap fault for a message
     * @param pOutMessage SOAP message
     * @param pService ISO service name
     * @param qName Qualified soap fault name
     * @param pFaultString fault string
     * @return
     * @throws SOAPException
     */
    public static SOAPMessage createSOAPFaultMessage(
            SOAPMessage pOutMessage,
        	String pService,
            Name qName,
            String pFaultString)
            throws SOAPException {
            SOAPBody body = pOutMessage.getSOAPPart().getEnvelope().getBody();
            SOAPFault fault = body.addFault();
            fault.setFaultCode(qName);
            fault.setFaultString(pFaultString);

            return pOutMessage;
    }
    
    
    public static SOAPMessage createSOAPFaultMessage(
            SOAPMessage pOutMessage,
        	String pService,
            String pFaultCode,
            String pFaultString,
            String pFaultDetails)
            throws SOAPException {
            SOAPBody body = pOutMessage.getSOAPPart().getEnvelope().getBody();
            SOAPFault fault = body.addFault();
            fault.setFaultCode(pFaultCode);
            fault.setFaultString(pFaultString);
            fault.addDetail().addTextNode(pFaultDetails);
            return pOutMessage;
        }
    
    /**
     * create a soap message with a blank message body and no headers.
     * @return - the soap Message
     * @throws SOAPException 
     * @throws SOAPException - if a messageFactory exception occurs while trying to create the message.
     */
    public static SOAPMessage createNewSoapMessage() 
    throws SOAPException {
    	return MessageFactory.newInstance().createMessage();
	}

    public static String createSOAPFaultString(String pResponseData){
    	if (logger.isDebugEnabled()) {
            // Strip XML header
            logger.debug("Entering createSOAPFaultString");
            
        }
    	String msg = "";
   	 	if (pResponseData != null && pResponseData.length() > 0){
   		 msg = pResponseData.substring(pResponseData.indexOf("?>") + 2);
   	 	}

        if (logger.isDebugEnabled()) {
            logger.debug("\n\n\ncreateSOAPString parsed");
        }

        // Add SOAP ENV header and footer. This seems too easy an may need
        // a parser
        msg = Constants.SOAP_FAULT_HEADER + msg + Constants.SOAP_FAULT_FOOTER;

        if (logger.isDebugEnabled()) {
            logger.debug("\n\n\nformatted parsed: " + msg);
        }
        return msg;
    }
    
    public static String createSOAPString(
            String pResponseData) {
    	 if (logger.isDebugEnabled()) {
             // Strip XML header
             logger.debug("Entering createSOAPString");
         }
    	 String msg = "";
    	 if (pResponseData != null && pResponseData.length() > 0){
    		 msg = pResponseData.substring(pResponseData.indexOf("?>") + 2);
    	 }

         if (logger.isDebugEnabled()) {
             logger.debug("\n\n\ncreateSOAPString parsed");
         }

         // Add SOAP ENV header and footer. This seems too easy an may need
         // a parser
         msg = Constants.SOAP_HEADER + msg + Constants.SOAP_FOOTER;

         if (logger.isDebugEnabled()) {
             logger.debug("\n\n\nformatted parsed: " + msg);
         }
         return msg;

    }
    /**
     * Creates a SOAPMessage from XML Data It is assumed at this point that the
     * data has been validated.
     *
     * @param pOutMessage SOAPMessage for factory access
     * @param pResponseData XML data
     *
     * @return SOAPMessage Returns pOutMessage for convience.
     *
     * @throws SOAPException
     * 
     */
    public static SOAPMessage createSOAPMessage(
        SOAPMessage pOutMessage,
        String pResponseData)
        throws SOAPException {
        if (logger.isDebugEnabled()) {
            // Strip XML header
            logger.debug("Entering createSOAPMessage");
        }

        String msg = createSOAPString(pResponseData);

        // Convert XML response into SOAPMessage
        DOMSource domSource;
        DocumentBuilderFactory docFactory =
            DocumentBuilderFactory.newInstance();
        DocumentBuilder builder;

        try {
            builder = docFactory.newDocumentBuilder();

            Document document =
                builder.parse(new ByteArrayInputStream(msg.getBytes()));
            domSource = new DOMSource(document);

            // Get the SOAP part and set its content to domSource
            SOAPPart soapPart = pOutMessage.getSOAPPart();
            soapPart.setContent(domSource);
        } catch (ParserConfigurationException e) {
            throw new SOAPException(e);
        } catch (SAXException e) {
            throw new SOAPException(e);
        } catch (IOException e) {
            throw new SOAPException(e);
        }

        return pOutMessage;
    }

    /**
     * Creates a SOAP Fault Message and populates the Detail with data returned
     * in the OutputDataTypeException
     *
     * @param pOutMessage
     * @param pOutputData
     * @param pHelper
     *
     * @return SOAP Fault Message
     *
     * @throws SOAPException
     */
    public static String createStandardFaultString(
        OutputDataTypeException pOutputData,
        ServiceHelper pHelper)
        throws SOAPException {
        String msg = null;

        try {
            if (!pOutputData.isXML()) {
                XMLBindUtility bindUtility =
                    new XMLBindUtility("com.caiso.soa._2006_06_13");
                msg = bindUtility.marshal(
                        pOutputData.getOutputData());
            } else {
                msg = (String) pOutputData.getOutputData();
            }
        } catch (XMLBindException e) {
            throw new SOAPException(e);
        }

        if (
            // Strip XML header
            logger.isDebugEnabled()) {
            // Strip XML header
            logger.debug("Entering createStandardFaultMessage: " + msg);
        }

        msg = msg.substring(msg.indexOf("?>") + 2);

        if (logger.isDebugEnabled()) {
            logger.debug("\n\n\ncreateStandardFaultMessage: " + msg);
        }

        // Add SOAP ENV header and footer. This seems too easy an may need
        // a parser
        msg = Constants.SOAP_FAULT_HEADER + msg + Constants.SOAP_FAULT_FOOTER; 

        if (logger.isDebugEnabled()) {
            logger.debug("\n\n\nformatted parsed: " + msg);
        }
        return msg;
    }   
    
    /**
     * Creates a SOAP Fault Message and populates the Detail with data returned
     * in the OutputDataTypeException
     *
     * @param pOutMessage
     * @param pOutputData
     * @param pHelper
     *
     * @return SOAP Fault Message
     *
     * @throws SOAPException
     * 
     */
    public static SOAPMessage createStandardFaultMessage(
        SOAPMessage pOutMessage,
        OutputDataTypeException pOutputData,
        ServiceHelper pHelper)
        throws SOAPException {
        String msg = null;
        msg = createStandardFaultString(pOutputData, pHelper);
        
        // Convert XML response into SOAPMessage
        DOMSource domSource;
        DocumentBuilderFactory docFactory =
            DocumentBuilderFactory.newInstance();
        DocumentBuilder builder;

        try {
            builder = docFactory.newDocumentBuilder();

            Document document =
                builder.parse(new ByteArrayInputStream(msg.getBytes()));
            domSource = new DOMSource(document);

            // Get the SOAP part and set its content to domSource
            SOAPPart soapPart = pOutMessage.getSOAPPart();
            soapPart.setContent(domSource);
        } catch (ParserConfigurationException e) {
            throw new SOAPException(e);
        } catch (SAXException e) {
            throw new SOAPException(e);
        } catch (IOException e) {
            throw new SOAPException(e);
        }

        return pOutMessage;
    }

/**
 * 
 * @param elementName
 * @param elementNameSpace
 * @return
 * @throws XMLBindException
 */
    public static String xmlFromSoapFault(
        SOAPMessage pInMessage,
        String elementName,
        String elementNameSpace)
        throws XMLBindException {
    	String result = null;	
    	
    	try {	
				SOAPBody body = pInMessage.getSOAPPart().getEnvelope().getBody();
    		Detail xmlFaultDetails = body.getFault().getDetail();
    		/*
    		 * There is a detail so this must be a standardOutput object. We will strip
    		 * if off.
    		 */
    		if (xmlFaultDetails != null) {
    			// Convert Node to xml string
    			 ByteArrayOutputStream baos = new ByteArrayOutputStream();
                 StreamResult stream = new StreamResult(baos);
                 Transformer transformer = cachedFaultXSLT.newTransformer();
                 transformer.transform(
                     pInMessage.getSOAPPart().getContent(),
                     stream);
                 result = new String(baos.toByteArray());
 
    		 }
    	} catch (TransformerException e) {
            throw new XMLBindException(e);
    	} catch (SOAPException e){
    		 throw new XMLBindException(e);
    	}
    	return result;
    	
    }
    	
    public static String xmlFromTextMessage(String pInMessage) 
    	throws XMLBindException {
    	try {
    		StreamSource source = new StreamSource(new ByteArrayInputStream(pInMessage.getBytes()));
    		ByteArrayOutputStream baos = new ByteArrayOutputStream();
    		StreamResult stream = new StreamResult(baos);
    		Transformer transformer = cachedXSLT.newTransformer();
    		transformer.transform(
    				source,
    				stream);
    		return new String(baos.toByteArray());
    	} catch (TransformerException e) {
    		throw new XMLBindException(e);
    	}
    }
    /**
     * Gets raw xml out of soap message
     *
     * @param pInMessage the soap message to extract the xml from
     * @param elementName the element name that defines the xml in the soap body 
     * @param elementNameSpace the element name space that defines the xml in the soap body.
     *
     * @return the raw xml string represented by the elementName and elementNameSpace
     *
     * @throws XMLBindException If the transformer fails to transform the DOM Element into XML or if
     * getting any part of the SOAPMessage fails the associated exceptions are rethrown as XMLBindExceptions
     *
     */
    public static String xmlFromSoapMessage(SOAPMessage pInMessage,
    		String elementName,
    		String elementNameSpace) 
    	throws XMLBindException {
    	String result = null;

        try {
            SOAPEnvelope envelope = pInMessage.getSOAPPart().getEnvelope();
            SOAPBody body = envelope.getBody();

            Iterator iter =
                body.getChildElements(
                    envelope.createName(elementName, null, elementNameSpace));

           if (iter.hasNext()) {
                // Convert Node to xml string
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                StreamResult stream = new StreamResult(baos);
                Transformer transformer = cachedXSLT.newTransformer();
                transformer.transform(
                    pInMessage.getSOAPPart().getContent(),
                    stream);
                result = new String(baos.toByteArray());
            }
            return result;
        } catch (TransformerException e) {
            throw new XMLBindException(e);
    	} catch (SOAPException e) {
    		throw new XMLBindException(e);
    	}
    }
    /**
     * Set the soap action into the passed in soap message.
     * @param pMessage - the soap message
     * @param pSoapAction - the soap action
     */
    public static void setSoapAction(SOAPMessage pMessage, String pSoapAction){
    	MimeHeaders headers = pMessage.getMimeHeaders();
    	headers.setHeader("soapaction", pSoapAction);
    }
    
    /**
     * Check for null value if value is null then return valueName is NULL
     * @param valueName - the name of the value to report as null
     * @param value - the value to check for null
     * @return - String with either the value if it is not null or valueName is NULL string.
     */
    public static String nullCheck(String valueName, String value){
    	String result = value;
    	if (value == null){
    		result = valueName + " is NULL";
    	}
    	return result;
    }
    
   /**
    * Create an outputDataType object
    * 
    * @param eventResult The result of the event.
    * @param eventName The name for this event.
    * @param eventSeverity The severity for the Event.
    * @param eventType The type of the event.
    * @param eventDescription Any description associated with the event.
    * @param serviceName The serviceName that spawned the event.
    * @param serviceDescription The service Description
    * @param serviceComments Any service related comments
    * @return An XML String representing an OutputDataType.
    * 
    * @throws JAXBException
    * @throws XMLBindException
    */
    public static String createOutputDataType(String eventResult, String eventName, String eventSeverity,
			String eventType, String eventDescription, String serviceName, String serviceDescription,
			String serviceComments) throws JAXBException, XMLBindException {
		Calendar now = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
		ObjectFactory factory = new ObjectFactory();
		OutputDataType outputData = factory.createOutputDataType();
		EventLog eventLog = factory.createEventLog();
		XMLGregorianCalendar date = null;
		try {
			date = getCalendar(now);
		} catch (DatatypeConfigurationException e) {
			e.printStackTrace();
		}
		eventLog.setCreationTime(date);
		eventLog.setId(UUIDGenerator.randomUUID().toString());
		eventLog.setCollectionQuantity("1");

		Event event = factory.createEvent();
		event.setId("1");
		event.setCreationTime(date);
		event.setDescription(eventDescription);
		event.setEventType(eventType);
		event.setSeverity(eventSeverity);
		event.setResult(eventResult);
		event.setName(eventName);
		eventLog.getEvent().add(event);

		Service service = factory.createService();
		service.setId(UUIDGenerator.randomUUID().toString());
		service.setName(serviceName);
		service.setDescription(serviceDescription);
		service.setComments(serviceComments);
		
		eventLog.getService().add(service);

		outputData.getEventLog().add(eventLog);

		XMLBindUtility bindUtility = new XMLBindUtility("com.caiso.soa._2006_06_13");
		return bindUtility.marshal(outputData);
	}

    
    public static String createOutputDataString(String eventResult, 
    		String eventName,
    		String eventSeverity,
    		String eventType,
    		String eventDescription,
    		String serviceName,
    		String serviceDescription,
    		String serviceComments
    		) {
    	return createOutputDataError(eventResult, eventName,
    			eventSeverity, eventType, eventDescription,
    			serviceName, serviceDescription, serviceComments);
    }
    
    /**
     * Create an output Data Error Object 
     * @param eventResult - Result Codes follow the format of event type abbreviation and a numeric
     * value such as FRMK0001, GNRL0001, JMS0001 etc 
     * @param eventName - A Constants that reflects the source system of the event FRAMEWORK, INTEGRATION, PI etc.
     * @param eventSeverity - One of the following values FATAL, ERROR, WARN, INFO
     * @param eventType - Predefined constant that reflects the event type abbreviation such as FRMK, GNRL, JMS etc.
     * @param eventDescription - Details of the error
     * @param serviceName - The service name the error occured in.
     * @param serviceDescription - Additional description for this service
     * @param serviceComments - Service Comments.
     * @return
     */
    public static String createOutputDataError(
    		String eventResult, 
    		String eventName,
    		String eventSeverity,
    		String eventType,
    		String eventDescription,
    		String serviceName,
    		String serviceDescription,
    		String serviceComments
    		) {
    	StringBuffer result = new StringBuffer();
        SimpleDateFormat dateFormatter = new SimpleDateFormat("%Y-%M-%D");
        SimpleDateFormat dateFormatter1 = new SimpleDateFormat("%Y-%M-%DT%h:%m:%s%z");
        
        Calendar now = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
      
        result.append(OutputDataTypeConstants.TAG_HEADER);
        result.append(OutputDataTypeConstants.TAG_OPEN_EVENT_LOG);
        result.append(OutputDataTypeConstants.TAG_OPEN_ID);
        result.append(UUIDGenerator.randomUUID().toString());
        result.append(OutputDataTypeConstants.TAG_CLOSE_ID);
        result.append(OutputDataTypeConstants.TAG_OPEN_CREATION_TIME);
        result.append(dateFormatter.format(now));
        result.append(OutputDataTypeConstants.TAG_CLOSE_CREATION_TIME);
        result.append(OutputDataTypeConstants.TAG_OPEN_COLLECITON_QTY);
        result.append("1");
        result.append(OutputDataTypeConstants.TAG_CLOSE_COLLECTION_QTY);
        result.append(OutputDataTypeConstants.TAG_OPEN_EVENT);
        result.append(OutputDataTypeConstants.TAG_OPEN_RESULT);
        result.append(StringEscapeUtils.escapeXml(eventResult));
        result.append(OutputDataTypeConstants.TAG_CLOSE_RESULT);
        result.append(OutputDataTypeConstants.TAG_OPEN_ID);
        result.append("1");
        result.append(OutputDataTypeConstants.TAG_CLOSE_ID);
        result.append(OutputDataTypeConstants.TAG_OPEN_NAME);
        result.append(StringEscapeUtils.escapeXml(eventName));
        result.append(OutputDataTypeConstants.TAG_CLOSE_NAME);
        result.append(OutputDataTypeConstants.TAG_OPEN_DESCRIPTION);
        result.append(StringEscapeUtils.escapeXml(eventDescription));
        result.append(OutputDataTypeConstants.TAG_CLOSE_DESCRIPTION);
        result.append(OutputDataTypeConstants.TAG_OPEN_CREATION_TIME);
        result.append(dateFormatter1.format(now));
        result.append(OutputDataTypeConstants.TAG_CLOSE_CREATION_TIME);
        result.append(OutputDataTypeConstants.TAG_OPEN_SEVERITY);
        result.append(StringEscapeUtils.escapeXml(eventSeverity));
        result.append(OutputDataTypeConstants.TAG_CLOSE_SEVERITY);
        result.append(OutputDataTypeConstants.TAG_OPEN_EVENT_TYPE);
        result.append(StringEscapeUtils.escapeXml(eventType));
        result.append(OutputDataTypeConstants.TAG_CLOSE_EVENT_TYPE);
        result.append(OutputDataTypeConstants.TAG_CLOSE_EVENT);
        result.append(OutputDataTypeConstants.TAG_OPEN_SERVICE);
        result.append(OutputDataTypeConstants.TAG_OPEN_ID);
        result.append(UUIDGenerator.randomUUID().toString());
        result.append(OutputDataTypeConstants.TAG_CLOSE_ID);
        result.append(OutputDataTypeConstants.TAG_OPEN_NAME);
        result.append(StringEscapeUtils.escapeXml(serviceName));
        result.append(OutputDataTypeConstants.TAG_CLOSE_NAME);
        result.append(OutputDataTypeConstants.TAG_OPEN_DESCRIPTION);
        result.append(StringEscapeUtils.escapeXml(serviceDescription));
        result.append(OutputDataTypeConstants.TAG_CLOSE_DESCRIPTION);
        result.append(OutputDataTypeConstants.TAG_OPEN_COMMENTS);
        result.append(StringEscapeUtils.escapeXml(serviceComments));
        result.append(OutputDataTypeConstants.TAG_CLOSE_COMMENTS);
        result.append(OutputDataTypeConstants.TAG_CLOSE_SERVICE);
        result.append(OutputDataTypeConstants.TAG_CLOSE_EVENT_LOG);
        result.append(OutputDataTypeConstants.TAG_FOOTER);
        return result.toString();
    }
    
    /**
     * Create an RPC Style OutputDataType Response. RPC style requires the operation name 
     * and namespace as the outer tag and then the part name as the next tag instead of the
     * outputDataType tag. Finally the outputDataType namespace needs to be added to the
     * first inner tag, in this case the EventLog tag. See notes below embedded in the method
     * constructRPCStyleResponse
     * 
     * @param eventResult
     * @param eventName
     * @param eventSeverity
     * @param eventType
     * @param eventDescription
     * @param serviceName
     * @param serviceDescription
     * @param serviceComments
     * @param operationName
     * @param nameSpace
     * @param partName
     * @return A String representing the outputDataType in RPC format.
     * @throws JAXBException 
     * @throws XMLBindException 
     * @throws SOAPException
     */
    public static String createRPCStyleResponse(String eventResult, 
    		String eventName,
    		String eventSeverity,
    		String eventType,
    		String eventDescription,
    		String serviceName,
    		String serviceDescription,
    		String serviceComments,
    		String operationName,
    		String nameSpace,
    		String partName) 
    throws XMLBindException, JAXBException, SOAPException {
    	
    	String data;
		
		data = createOutputDataType(eventResult,
				eventName, eventSeverity, eventType,
				eventDescription, serviceName, 
				serviceDescription, serviceComments);
			
			try {
				data= constructRPCStyleResponse(
						data, 
						operationName,
						nameSpace,
						partName);
			} catch (ParserConfigurationException e) {
				throw new SOAPException(e.getMessage(), e);
			} catch (SAXException e) {
				throw new SOAPException(e.getMessage(), e);
			} catch (IOException e) {
				throw new SOAPException(e.getMessage(), e);			
			} catch (TransformerException e) {
				throw new SOAPException(e.getMessage(), e);
			}
			return data;
    }
    
    /**
     * Parse an RPC Style OutputDataType Response back to the standard outputDataType object that
     * jaxb expects. The incoming message will be formated the part name as the 
     * first child tag rather than the outputDataType tag. The outputDataType namespace is also found 
     * on the first inner tag. This method removes the xml namespace from the event log tag
     * and replaces the part name tag with the outputDataType tag with associated namespace.
     * 
     * @parem response the response xml
     * @param elementName
     * @return A String representing the outputDataType in RPC format.
     * @throws JAXBException 
     * @throws XMLBindException 
     * @throws SOAPException
     */
    public static String parseRPCStyleResponse(String response,
    		String firstInnerTag,
    		String elementName) 
    throws SOAPException {
    	
    	String data;
			
			try {
				data= deconstructRPCStyleResponse(
						response,
						firstInnerTag,
						elementName);
			} catch (ParserConfigurationException e) {
				throw new SOAPException(e.getMessage(), e);
			} catch (SAXException e) {
				throw new SOAPException(e.getMessage(), e);
			} catch (IOException e) {
				throw new SOAPException(e.getMessage(), e);			
			} catch (TransformerException e) {
				throw new SOAPException(e.getMessage(), e);
			}
			return data;
    }
    
    /**
     * Reconstitute a response from xml string in Data with
     * the outer tag equal to the elementName and the namespace moved from the
     * inner eventLog tag back to the outer elementName tag.
     * @param data - XML String representing OutputDataType as formatted by JAXB 
     * @param elementName - the elementName tag 
     * @return - a DOM Document that contains the structure as described above.
     * @throws ParserConfigurationException - if the parser cannot be setup properly I guess??
     * @throws SAXException - throw by xmlToDom if the XML is unparsable
     * @throws IOException - thrown by xmlToDom if there is a problem reading the input stream
     * @throws TransformerException  if the resulting DOM document fails to transform back to XML
     * @throws SOAPException 
     */
    private static String deconstructRPCStyleResponse(
    		String data,
    		String firstInnerTag,
    		String elementName) 
    throws ParserConfigurationException, SAXException, IOException, TransformerException, SOAPException {
    	Document document = xmlToDom(data);
    	
    	/* We are assuming that the first child node is the partName node 
    	 * then the next child will be the eventLogNode 
    	 */
    	Node partNameNode = document.getFirstChild();
    	Node eventLogNode = null;
		NodeList eventLogNodes = partNameNode.getChildNodes();
		for (int i=0; i < eventLogNodes.getLength(); i++){
			if (eventLogNodes.item(i).getNodeName().equalsIgnoreCase(firstInnerTag)){
				eventLogNode = eventLogNodes.item(i);
				break;
			}
		}
		
		if (eventLogNode == null){
			throw new SOAPException("Response data does not contain " + firstInnerTag + " node");
		}

		/*Get the value for the XMLNS attribute to add to the outputData tag */
		Node nsNode = eventLogNode.getAttributes().getNamedItem(XMLNS);
		
		String nsValue = null;
		if (nsNode != null) {
			nsValue = nsNode.getNodeValue();
		} else {
			throw new SOAPException("Namespace attribute " + XMLNS + " Does not exist in first child node");
		}
		
		/* Remove the eventlogNode name space attribute and add it to the new outer node. */
		eventLogNode.getAttributes().removeNamedItem(XMLNS);
		
		/*Create a new node for the namespace attribute to add to the element name node */
		Node nameSpaceNode = document.createAttribute(XMLNS);
		nameSpaceNode.setNodeValue(nsValue);
		
		Node elementNameNode = document.createElement(elementName);
		
		/* Set the outputData namespace as an attribute of the elementNameNode tag */
		elementNameNode.getAttributes().setNamedItem(nameSpaceNode);
		
		/*Add the eventLog tag back to the elementNameNode as a child */
		elementNameNode.appendChild(eventLogNode);
		
		/*Replace the partName with the elementNameNode */
		document.replaceChild(elementNameNode, partNameNode);
		
		/*Convert the dom document back to XML before returning */
		return domToXML(document);
    }
    	
    
    /**
     * Create an rpcStyle Response from the xml string in Data with
     * the outer tag equal to the operation name with namespace and the next tag
     * equal to the partName parameter
     * @param data - XML String representing OutputDataType as formatted by JAXB 
     * @param operationName - the operationName to use as the outer tag
     * @param nameSpace - the nameSpace for the operationName tag
     * @param partName - the partName tag 
     * @return - a DOM Document that contains the structure as described above.
     * @throws ParserConfigurationException - if the parser cannot be setup properly I guess??
     * @throws SAXException - throw by xmlToDom if the XML is unparsable
     * @throws IOException - thrown by xmlToDom if there is a problem reading the input stream
     * @throws TransformerException  if the resulting DOM document fails to transform back to XML
     * @throws SOAPException 
     */
    private static String constructRPCStyleResponse(
    		String data, 
    		String operationName,
    		String nameSpace,
    		String partName) 
    throws ParserConfigurationException, SAXException, IOException, TransformerException, SOAPException {
    	
    	/*
    	 * Create a DOM document object. This document will initially contain
    	 * the outputDAtaType object that was created using the JAXB object model
    	 * 
    	 * Because RCP requires a format different from the actual XSD we will reformat
    	 * the output appropriately. 
    	 *   1. Get the NameSpace from the outputDataType tag by accessing the associated 
    	 *      attribute
    	 *   2. Create an attribute node for the NameSpace
    	 *   3. Get the first child of the outputDataType which should be the EventLog tag.
    	 *   4. Add the namespace attribute node to this tag
    	 *   5. Replace the outputDataType child in the DOM Document with the new EventLog
    	 *      Node.
    	 * The resulting output will now look like this. Notice the outputDataType tag has been removed.
    	 * <EventLog xmlns="http://www.caiso.com/soa/20060613/OutputDataType.xsd">
    	 *  ... the rest of the body ...
    	 * </EventLog>
    	 */
    	
    	/*Create a DOM document structure form the inbound XML */
    	Document document = xmlToDom(data);
    	
    	/*The first child node should be the outputDataNode */
		Node outputDataNode = document.getFirstChild();
		
		/*Get the value for the XMLNS attribute to add to the event log tag */
		Node nsNode = outputDataNode.getAttributes().getNamedItem(XMLNS);
		
		String nsValue = null;
		if (nsNode != null) {
			nsValue = nsNode.getNodeValue();
		} else {
			throw new SOAPException("Namespace attribute " + XMLNS + " Does not exist in first child node");
		}
		
		
		/*Create a new node for the namespace attribute to add to the event log node */
		Node nameSpaceNode = document.createAttribute(XMLNS);
		nameSpaceNode.setNodeValue(nsValue);
		
		/*Should get the eventLog Node from the first child. */
		Node eventLogNode = outputDataNode.getFirstChild();
		
		/* Set the outputData namespace as an attribute of the event log tag */
		eventLogNode.getAttributes().setNamedItem(nameSpaceNode);
		
		/* 
		 * Now build the tree with operation name and namespace as the first child,
		 */
		Node partNameNode = document.createElement(partName);
		partNameNode.appendChild(eventLogNode);
		
		/*If the operationName does not contain a prefix then we need to add one
		 * if the operationName contains a colon then it is prefixed else we will add the 
		 * generic NS1 prefix 
		 */
		if (operationName.indexOf(':') == -1 ){
			operationName = Constants.NS1 + ":" + operationName;
		}
		Node operationNameNode = document.createElementNS(nameSpace, operationName + Constants.RESPONSE_SUFFIX); 
		operationNameNode.appendChild(partNameNode);
		
			
		/*Replace the outputDataNode with the eventLogNode */
		document.replaceChild(operationNameNode, outputDataNode);
		
		/*Convert the dom document back to XML before returning */
		return domToXML(document);
    }
    
    private static Document xmlToDom(String xml) throws ParserConfigurationException, SAXException, IOException{
    	DocumentBuilderFactory docFactory =
               DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = docFactory.newDocumentBuilder();
    	Document document = builder.parse(new ByteArrayInputStream(xml.getBytes()));
    	return document;
    }
    
    private static String domToXML(Document domDocument) throws TransformerException{
    	/*Use JAXP to parse the DOM structure into XML */
		DOMSource source = new DOMSource(domDocument);
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		StreamResult result = new StreamResult(baos);
		TransformerFactory tf = TransformerFactory.newInstance();
		Transformer serializer = tf.newTransformer();
		serializer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
		serializer.setOutputProperty(OutputKeys.INDENT, "yes");
		serializer.transform(source, result);
		return baos.toString();
    }
    /**
     *
     * Create an output Data Error Object with service Name, message and event result 
     * @param serviceName - Name of the service that the error occured for
     * @param eventDescription - a description of the Error
     * @param eventResult - Result Codes follow the format of event type abbreviation and a numeric
     * value such as FRMK0001, GNRL0001, JMS0001 etc
     * @return - an XML String formated as an outputDataType
     */
    public static String createOutputDataError(String serviceName, String eventDescription, String eventResult){
        
    	return createOutputDataError(
    				eventResult,
    				SOAStatusConstants.NAME_FRAMEWORK,
    				SOAStatusConstants.SEVERITY_ERROR,
    				SOAStatusConstants.FRAMEWORK_PREFIX,
    				eventDescription,
    				serviceName,
    				SOAStatusConstants.NAME_FRAMEWORK,
    				"None"
    				);
        }
        
    /**
     * Create an output Data Error Object with service Name, stack trace and message and event result 
     * @param serviceName - Name of the service that the error occured for
     * @param t - the Error
     * @param eventResult - Result Codes follow the format of event type abbreviation and a numeric
     * value such as FRMK0001, GNRL0001, JMS0001 etc
     * @return - an XML String formated as an outputDataType
     */
    public static String createOutputDataError(String serviceName, Throwable t, String eventResult){
        	return createOutputDataError(
        				serviceName, 
        				SOASysUtility.getExceptionMessageAndStackTrace(t), 
        				eventResult);
    }
    public static XMLGregorianCalendar getCalendar(Calendar now) throws DatatypeConfigurationException {
		GregorianCalendar cal = new GregorianCalendar(TimeZone.getTimeZone("GMT"));
		cal.setTime(now.getTime());
		return DatatypeFactory.newInstance().newXMLGregorianCalendar(cal);
		
	}
}
