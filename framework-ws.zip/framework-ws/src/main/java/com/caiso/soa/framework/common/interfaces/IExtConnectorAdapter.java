package com.caiso.soa.framework.common.interfaces;

import java.util.Map;

import com.caiso.soa.framework.common.exception.ConnectorException;
import com.caiso.soa.framework.common.exception.OutputDataTypeException;

/*
 * Interface for all JCA connector implementations.
 *
 * @author <a href="mailto:mpope@caiso.com?Subject=JAVADOC - Question about com.caiso.soa.framework.ejb.connector.IConnectorAdapter.java"> Mark Pope</a>
 * @version $Revision:  $ $Date:  $
 *
 * @Copyright (c) California ISO 2005
 *
 */
public interface IExtConnectorAdapter extends IConnector{	    

    /**
     * Payload is XML data
     *
     * @param pService Service name
     * @param pPayload data as XML
     *
     * @return
     *
     * @throws ConnectorException
     * @throws OutputDataTypeException
     */
    public String onMessage(String pService, String pPayload, Map pMessageHeader)
        throws ConnectorException, OutputDataTypeException;

    /**
     * Payload is JAXB object
     *
     * @param pService Service name
     * @param pPayload data as JAXB object model
     *
     * @return
     *
     * @throws ConnectorException
     * @throws OutputDataTypeException
     */
    public Object onMessage(String pService, Object pPayload, Map pMessageHeader)
        throws ConnectorException, OutputDataTypeException;
}

