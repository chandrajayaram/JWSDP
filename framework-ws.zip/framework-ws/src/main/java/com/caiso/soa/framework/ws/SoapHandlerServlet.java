package com.caiso.soa.framework.ws;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.DecimalFormat;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.Name;
import javax.xml.soap.SOAPConstants;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.caiso.soa.common.util.SOASysUtility;
import com.caiso.soa.framework.common.Constants;
import com.caiso.soa.framework.common.OutputDataTypeConstants;
import com.caiso.soa.framework.common.SOAStatusConstants;
import com.caiso.soa.framework.common.exception.OutputDataTypeException;
import com.caiso.soa.framework.common.interfaces.IConnector;
import com.caiso.soa.framework.common.interfaces.IConnectorAdapter;
import com.caiso.soa.framework.common.interfaces.IExtConnectorAdapter;
import com.caiso.soa.framework.common.util.SOAPUtility;
import com.caiso.soa.framework.common.util.SaajUtils;
import com.caiso.soa.framework.common.util.ServiceHelper;

/**
 * This class provides base functionality for dealing with soap requests. Users
 * should override the onMessage method.
 *
 * @version 1.10 3/18/2010
 * @author Rick Tully
 *
 *         Copyright (c) California ISO
 */
@WebServlet(urlPatterns = { "/caiso/SyncMessagingService/*" })
public class SoapHandlerServlet extends HttpServlet {
	public static final String SOAP_ACTION = "SOAPAction";

	@Autowired
	private IConnector persistenceConnector;

	@Value("${wsdl.style.document}")
	private String wsdlStyleDocument;

	private static final long serialVersionUID = 1L;

	protected MessageFactory messageFactory;

	private Logger logger = LoggerFactory.getLogger(SoapHandlerServlet.class);

	public void init() throws ServletException {
		try {
			// Initialize it to the default.
			messageFactory = MessageFactory.newInstance();
		} catch (Exception ex) {
			throw new ServletException("Unable to create message factory" + ex.getMessage());
		}
	}

	protected void processRequest(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {

		// resp.setContentType("text/html;charset=UTF-8");

		try {
			// Get all the headers from the HTTP request.
			MimeHeaders headers = SaajUtils.getHeaders(req);

			// Get the body of the HTTP request.
			InputStream is = req.getInputStream();

			// Now internalize the contents of a HTTP request and
			// create a SOAPMessage
			SOAPMessage msg = messageFactory.createMessage(headers, is);

			// There are no replies in case of an OnewayListener.
			SOAPMessage reply = onMessage(msg);

			if (reply != null) {

				// Need to saveChanges 'cos we're going to use the
				// MimeHeaders to set HTTP response information. These
				// MimeHeaders are generated as part of the save.

				if (reply.saveRequired()) {
					reply.saveChanges();
				}

				resp.setStatus(HttpServletResponse.SC_OK);

				SaajUtils.putHeaders(reply.getMimeHeaders(), resp);

				// Write out the message on the response stream.
				OutputStream os = resp.getOutputStream();
				reply.writeTo(os);

				os.flush();

			} else {
				resp.setStatus(HttpServletResponse.SC_NO_CONTENT);
			}
		} catch (Exception ex) {
			throw new ServletException("Saaj POST failed " + ex.getMessage());
		}
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		processRequest(request, response);

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		processRequest(request, response);

	}

	public SOAPMessage onMessage(SOAPMessage pInMessage) {
		SOAPMessage outMessage = null;
		try {
			ServiceHelper serviceHelper = new ServiceHelper(pInMessage, wsdlStyleDocument);
			SoapMessageHelper soapMessageHelper = new SoapMessageHelper(pInMessage);
			try {
				String payload = soapMessageHelper.getPayload();
				Map<?, ?> messageProperties = soapMessageHelper.getMessageProperties(pInMessage);

				String responseData = null;

				if (persistenceConnector instanceof IConnectorAdapter) {
					responseData = ((IConnectorAdapter) persistenceConnector).onMessage(serviceHelper.getService(),
							payload);
				} else if (persistenceConnector instanceof IExtConnectorAdapter) {
					responseData = ((IExtConnectorAdapter) persistenceConnector).onMessage(serviceHelper.getService(),
							payload, messageProperties);
				}
				if (logger.isDebugEnabled()) {
					logger.debug("[processMessage] - Creating Soap Message from Payload:");
					if (Boolean.getBoolean(Constants.PRINT_PAYLOAD)) {
						logger.debug("[processMessage] - " + responseData);
					}
				}

				// outMessage = responseHelper.createSoapMessage(responseData);
			} catch (SOAPException e) {
				logger.error("[processMessage] Exception Occured", e);
				try {
					String output = createOutputDataType(e.getMessage(), 40, serviceHelper);
					outMessage = soapMessageHelper.createSOAPFaultMessage(output);
				} catch (SOAPException e2) {
					outMessage = handleFatalError(e2);
				}
			} catch (OutputDataTypeException e) {
				logger.error("[processMessage] Exception Occured", e);
				try {
					outMessage = soapMessageHelper.createSOAPFaultMessage(e);
				} catch (SOAPException e2) {
					outMessage = handleFatalError(e2);
				}
			}
		} catch (Throwable e) {
			/*
			 * This should only occur if the init method determines that it
			 * could not read the soap action from the message but we will catch
			 * throwable anyway just in case as we don't any exceptions to not
			 * be reported back to the calling process.
			 */
			logger.error("[onMessage] failed with the following exception:", e);
			try {
				/* Attempt to create a message and send back a fault */
				outMessage = SoapMessageHelper.createSOAPFaultMessageWithNamespace(Constants.SOAP_FAULT_CODE_SERVER,
						SOASysUtility.getExceptionMessageAndStackTrace(e), SOAPConstants.URI_NS_SOAP_ENVELOPE);

			} catch (Exception e2) {
				try {
					outMessage = handleFatalError(e2);
				} catch (Exception e3) {
					logger.error("[onMessage] - FATAL ERROR: could not create outbound SOAPMessage", e);
				}
			}
		}
		if (logger.isDebugEnabled()) {
			logger.debug("[onMessage] - returning OutMessage - No Exceptions");
		}
		return outMessage;
	}

	private SOAPMessage handleFatalError(Throwable e) throws SOAPException {
		logger.error("[onMessage] - Exception Occured: ", e);
		SOAPMessage msg = SOAPUtility.createNewSoapMessage();
		SOAPEnvelope env = msg.getSOAPPart().getEnvelope();
		Name qname = env.createName(Constants.SOAP_FAULT_CODE_SERVER, null, SOAPConstants.URI_NS_SOAP_ENVELOPE);
		msg = SOAPUtility.createSOAPFaultMessage(msg, "UNKNOWN", qname,
				SOASysUtility.getExceptionMessageAndStackTrace(e));
		return msg;
	}

	protected String createOutputDataType(String pMsg, int pID, ServiceHelper helper) {
		DecimalFormat format = new DecimalFormat("0000");
		String id = format.format(pID);
		return SOAPUtility.createOutputDataError(SOAStatusConstants.FRAMEWORK_PREFIX + id, "",
				OutputDataTypeConstants.SEVERITY_ERROR, SOAStatusConstants.FRAMEWORK_PREFIX, pMsg,
				SOAPUtility.nullCheck("ServiceName", helper.getService()),
				SOAPUtility.nullCheck(Constants.SERVICE_URI, helper.getServiceURI()), "No Comments");
	}

}