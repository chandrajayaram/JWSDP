package com.caiso.soa.framework.common;

public interface OutputDataTypeConstants {
	
	public static final String DATA_PACKAGE = "com.caiso.soa.framework.common.data";
	public static final String TAG_XML_HEADER ="<?xml version=\"1.0\" encoding=\"UTF-8\"?>"; 
	public static final String TAG_HEADER = TAG_XML_HEADER + 
		"<outputDataType xmlns=\"http://www.caiso.com/soa/2006-06-13/StandardOutput.xsd\" " +
		"xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" " +
		"xsi:schemaLocation=\"http://www.caiso.com/soa/2006-06-13/StandardOutput.xsd\">";
	public static final String TAG_FOOTER = "</outputDataType>";

	public static final String TAG_OPEN_EVENT_LOG = "<EventLog>";
	public static final String TAG_CLOSE_EVENT_LOG = "</EventLog>";
	public static final String TAG_OPEN_ID = "<id>";
	public static final String TAG_CLOSE_ID = "</id>";
	public static final String TAG_OPEN_NAME = "<name>";
	public static final String TAG_CLOSE_NAME = "</name>";
	public static final String TAG_OPEN_DESCRIPTION = "<description>";
	public static final String TAG_CLOSE_DESCRIPTION = "</description>";
	public static final String TAG_OPEN_CREATION_TIME = "<creationTime>";
	public static final String TAG_CLOSE_CREATION_TIME = "</creationTime>";
	public static final String TAG_OPEN_COLLECITON_QTY = "<collectionQuantity>";
	public static final String TAG_CLOSE_COLLECTION_QTY = "</collectionQuantity>";
	public static final String TAG_OPEN_EVENT = "<Event>";
	public static final String TAG_CLOSE_EVENT = "</Event>";
	public static final String TAG_OPEN_RESULT = "<result>";
	public static final String TAG_CLOSE_RESULT = "</result>";
	public static final String TAG_OPEN_SEVERITY = "<severity>";
	public static final String TAG_CLOSE_SEVERITY = "</severity>";
	public static final String TAG_OPEN_EVENT_TYPE = "<eventType>";
	public static final String TAG_CLOSE_EVENT_TYPE = "</eventType>";
	public static final String TAG_OPEN_SERVICE = "<Service>";
	public static final String TAG_CLOSE_SERVICE = "</Service>";
	public static final String TAG_OPEN_COMMENTS = "<comments>";
	public static final String TAG_CLOSE_COMMENTS = "</comments>";
	
	public static final String SEVERITY_ERROR = "ERROR";
	public static final String SEVERITY_WARN = "WARN";
	public static final String SEVERITY_INFO = "INFO";
	public static final String SEVERITY_FATAL = "FATAL";
}
