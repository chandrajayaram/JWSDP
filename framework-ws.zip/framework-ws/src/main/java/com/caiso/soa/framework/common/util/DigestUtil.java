package com.caiso.soa.framework.common.util;
import java.security.MessageDigest;

/**
*  Utilitity class useful for hashing functionality.
*
* @version 1.10 3/18/2010
* @author Rick Tully
*
* Copyright (c) California ISO
*/
public class DigestUtil {

    /**
     * Uses SHA-1 algorithm to hash Strings. String argument is converted
     * to byte[] with UTF-8 encoding.
     *
     * @param payload String to be digested.
     * @return byte[] the digest of the payload
     * @throws Exception If algoritm is not available or UTF-8 is not supported
     */
    public static byte[] digestSHA1(String payload)throws Exception{
		byte[] sha1hash =null;

        if(payload!=null){
            byte[] payloadBytes=payload.getBytes("UTF-8");
			sha1hash=digestSHA1(payloadBytes);
        }
		return sha1hash;
    }

    public static byte[] digestSHA1(byte[] payload)throws Exception{
		byte[] sha1hash =null;
        if(payload!=null){
			MessageDigest md=MessageDigest.getInstance("SHA-1");
	
			md.update(payload);

			sha1hash = md.digest();
        }
		return sha1hash;
    }

    public static String convertToHex(byte[] data) { 
        StringBuffer buf = new StringBuffer();
        for (int i = 0; i < data.length; i++) { 
            int halfbyte = (data[i] >>> 4) & 0x0F;
            int two_halfs = 0;
            do { 
                if ((0 <= halfbyte) && (halfbyte <= 9)) 
                    buf.append((char) ('0' + halfbyte));
                else 
                    buf.append((char) ('a' + (halfbyte - 10)));
                halfbyte = data[i] & 0x0F;
            } while(two_halfs++ < 1);
        } 
        return buf.toString();
    } 

}
