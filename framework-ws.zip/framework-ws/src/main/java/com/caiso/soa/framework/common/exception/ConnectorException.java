/*
 * Copyright (c) 2005 California ISO. All rights reserved.
 */
package com.caiso.soa.framework.common.exception;


/**
 * Generic exception for JCA Connector Exceptions
 */
public class ConnectorException
extends BaseException {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1002L;

	/**
     * Creates a new ConnectorException object.
     */
    public ConnectorException() {
        super();
    }

    /**
     * Creates a new ConnectorException object.
     *
     * @param pException exception message
     */
    public ConnectorException(Exception pException) {
        super(pException);
    }

    /**
     * Creates a new ConnectorException object.
     *
     * @param pString exception message
     */
    public ConnectorException(String pString) {
        super(pString);
    }

    /**
     * Creates a new ConnectorException object.
     *
     * @param pString exception message
     * @param pThrowable root exception
     */
    public ConnectorException(String pString, Throwable pThrowable) {
        super(pString, pThrowable);
    }
}
